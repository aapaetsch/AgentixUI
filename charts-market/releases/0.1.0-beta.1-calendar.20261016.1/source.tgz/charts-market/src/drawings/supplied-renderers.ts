import type { DrawingRendererDefinition, DrawingPrimitive, MarketTime, SuppliedCalculationResults } from "../core";
import { defaultDrawingHandles } from "./geometry";
import { builtInDrawingRenderers } from "./renderers";

/** Only these audited first-party renderers use coordinate geometry alone. */
export const suppliedGeometricDrawingTypes = ["trend-line", "horizontal-line", "vertical-line", "rectangle"] as const;

/** Never delegate to consumer renderers, derived callbacks or financial built-ins. */
export function createSuppliedDrawingRenderers(ids: string[], results: SuppliedCalculationResults): DrawingRendererDefinition[] {
  return [...new Set([...ids, "date-price-range"])].map(id => {
    const geometric = suppliedGeometricDrawingTypes.some(type => type === id)
      ? builtInDrawingRenderers.find(renderer => renderer.id === id) : undefined;
    if (geometric) return geometric;
    return {
      id,
      getHandles: defaultDrawingHandles,
      getPrimitives(context): DrawingPrimitive[] {
        const result = results[context.drawing.id];
        const available = result?.kind === "drawing" && (result.status === "available" || result.status === "partial");
        const primitives: DrawingPrimitive[] = [];
        if (available) {
          // Preserve gaps. Connecting across null points would imply unsupplied values.
          let segment: NonNullable<ReturnType<typeof context.coordinateFor>>[] = [];
          let previous: MarketTime | undefined;
          const flush = () => {
            if (segment.length > 1) primitives.push({ id: `supplied-${primitives.length}`, kind: "path", points: segment });
            else if (segment.length === 1) primitives.push({ id: `supplied-${primitives.length}`, kind: "ellipse", cx: segment[0].x, cy: segment[0].y, rx: 2, ry: 2 });
            segment = []; previous = undefined;
          };
          result.points.forEach(point => {
            const coordinate = point.value == null || context.isTimeSegmentContinuous?.(point.time, point.time) === false ? null : context.coordinateFor({ time: point.time, price: point.value });
            if (previous != null && context.isTimeSegmentContinuous?.(previous, point.time) === false) flush();
            if (coordinate) { segment.push(coordinate); previous = point.time; } else flush();
          });
          flush();
        }
        primitives.push({ id: "supplied-status", kind: "multiline-text", at: context.points[0] ?? { x: 8, y: 20 }, background: true,
          lines: available ? [result.provenanceLabel, ...Object.entries(result.derivedValues ?? {}).map(([key, value]) => `${key}: ${value}`)] : ["Calculation unavailable · supplied result required"] });
        return primitives;
      },
      derivedValues: context => {
        const result = results[context.drawing.id];
        return result?.kind === "drawing" && (result.status === "available" || result.status === "partial") ? result.derivedValues ?? {} : { available: false };
      },
    };
  });
}
