import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";
import { createRequire } from "node:module";

const knownManifest = "007c8a60d977ab5cda5d4ef95459f26f9d0eda8ac5d0be7975c5c27563c49aa4";
const knownEntry = "1d64dd2279d5af0a7201224b23de0b8a95aec9e7233995fccf915d876a731ead";
const sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");

/** Explicit, additive repair for the exact approved peer artifact; never an install hook. */
export function verifyPeerBoundary(peerDirectory, repair = false) {
  const root = fs.realpathSync(peerDirectory);
  const manifestPath = path.join(root, "package.json");
  const manifestBytes = fs.readFileSync(manifestPath);
  const manifest = JSON.parse(manifestBytes);
  const relativeEntry = manifest.exports?.["."]?.require ?? manifest.main;
  if (manifest.name !== "lucide-react") throw new Error("Expected the lucide-react package directory.");
  if (manifest.type !== "module" || relativeEntry?.replaceAll("\\", "/").replace(/^\.\//, "") !== "dist/cjs/lucide-react.js") {
    return { status: "not-applicable", package: manifest.name, version: manifest.version, changed: false };
  }
  const cjsDirectory = fs.realpathSync(path.join(root, "dist", "cjs"));
  if (!cjsDirectory.startsWith(root + path.sep)) throw new Error("CommonJS directory escapes the peer package.");
  const boundary = path.join(cjsDirectory, "package.json");
  if (fs.existsSync(boundary)) {
    if (JSON.parse(fs.readFileSync(boundary, "utf8")).type !== "commonjs") throw new Error("Existing CommonJS boundary is unexpected; refusing to overwrite it.");
    return { status: "valid", package: manifest.name, version: manifest.version, changed: false, boundary, sha256: sha256(fs.readFileSync(boundary)) };
  }
  if (!repair) throw new Error("Missing lucide-react CommonJS package boundary. Run this command with --repair to add the verified boundary explicitly.");
  const entry = path.join(cjsDirectory, "lucide-react.js");
  if (manifest.version !== "0.474.0" || sha256(manifestBytes) !== knownManifest || sha256(fs.readFileSync(entry)) !== knownEntry) {
    throw new Error("Peer bytes differ from the verified 0.474.0 artifact; refusing an unreviewed repair.");
  }
  fs.writeFileSync(boundary, '{"type":"commonjs"}\n', { flag: "wx" });
  return { status: "repaired", package: manifest.name, version: manifest.version, changed: true, boundary, sha256: sha256(fs.readFileSync(boundary)) };
}

if (process.argv[1] && fs.realpathSync(process.argv[1]) === fs.realpathSync(new URL(import.meta.url))) {
  try {
    const args = process.argv.slice(2);
    const directoryIndex = args.indexOf("--peer-dir");
    for (let index = 0; index < args.length; index++) {
      if (args[index] === "--repair") continue;
      if (args[index] === "--peer-dir" && args[index + 1] && !args[index + 1].startsWith("--")) { index++; continue; }
      throw new Error("Supported options: --repair, --peer-dir <lucide-react directory>.");
    }
    const directory = directoryIndex >= 0 ? args[directoryIndex + 1] : path.dirname(createRequire(import.meta.url).resolve("lucide-react/package.json"));
    console.log(JSON.stringify(verifyPeerBoundary(directory, args.includes("--repair")), null, 2));
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
