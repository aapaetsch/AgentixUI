import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { createHash } from "node:crypto";
import { test } from "node:test";
import assert from "node:assert/strict";
import { verifyPeerBoundary } from "./verify-peer-boundaries.mjs";

const installed = path.dirname(createRequire(import.meta.url).resolve("lucide-react/package.json"));
const temporary = path.resolve(".cache/peer-boundary-tests");
fs.mkdirSync(temporary, { recursive: true });
function fixture() {
  const root = fs.mkdtempSync(path.join(temporary, "peer-"));
  fs.mkdirSync(path.join(root, "dist/cjs"), { recursive: true });
  for (const name of ["package.json", "dist/cjs/lucide-react.js"]) fs.copyFileSync(path.join(installed, name), path.join(root, name));
  return root;
}
const hash = (file) => createHash("sha256").update(fs.readFileSync(file)).digest("hex");

test("check reports a missing boundary without mutating the dependency", () => {
  const root = fixture();
  assert.throws(() => verifyPeerBoundary(root), /Missing/);
  assert.equal(fs.existsSync(path.join(root, "dist/cjs/package.json")), false);
});
test("repair only adds the CommonJS boundary and is idempotent", () => {
  const root = fixture(), manifest = hash(path.join(root, "package.json")), entry = hash(path.join(root, "dist/cjs/lucide-react.js"));
  assert.equal(verifyPeerBoundary(root, true).changed, true);
  assert.equal(fs.readFileSync(path.join(root, "dist/cjs/package.json"), "utf8"), '{"type":"commonjs"}\n');
  assert.equal(hash(path.join(root, "package.json")), manifest);
  assert.equal(hash(path.join(root, "dist/cjs/lucide-react.js")), entry);
  assert.equal(verifyPeerBoundary(root, true).changed, false);
  assert.equal(verifyPeerBoundary(root).status, "valid");
});
test("unknown dependency bytes cannot be repaired", () => {
  const root = fixture();
  fs.appendFileSync(path.join(root, "dist/cjs/lucide-react.js"), "\n// unreviewed\n");
  assert.throws(() => verifyPeerBoundary(root, true), /differ/);
  assert.equal(fs.existsSync(path.join(root, "dist/cjs/package.json")), false);
});
test("an existing unexpected boundary is preserved", () => {
  const root = fixture(), boundary = path.join(root, "dist/cjs/package.json");
  fs.writeFileSync(boundary, '{"type":"module"}\n');
  assert.throws(() => verifyPeerBoundary(root, true), /refusing to overwrite/);
  assert.equal(fs.readFileSync(boundary, "utf8"), '{"type":"module"}\n');
});
test("a corrected future package needs no repair", () => {
  const root = fixture(), file = path.join(root, "package.json"), manifest = JSON.parse(fs.readFileSync(file, "utf8"));
  delete manifest.type;
  fs.writeFileSync(file, JSON.stringify(manifest));
  assert.equal(verifyPeerBoundary(root, true).status, "not-applicable");
  assert.equal(fs.existsSync(path.join(root, "dist/cjs/package.json")), false);
});
