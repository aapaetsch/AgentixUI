# aapaetsch-ui-kit Component Library Roadmap

This file is an index to the roadmap subfiles. Open any referenced file below to view that section in full — for LLM use, fetch only the subfile(s) you need.

## Roadmap sections (LLM-friendly references)

- Overview: short context and summary 
  - FILE: `docs/roadmap/overview.md`
- Components: core/layout/utility lists 
  - FILE: `docs/roadmap/components.md`
- Advanced Components: implemented & planned 
  - FILE: `docs/roadmap/advanced-components.md`
- Charts Package: `aapaetsch-charts` status and public surface
  - FILE: `docs/roadmap/charts.md`
- Market Charts Package: `aapaetsch-charts-market` architecture, features and release gates
  - FILE: `docs/roadmap/charts-market.md`
- Templates: page layouts and application shells 
  - FILE: `docs/roadmap/templates.md`
- Development Phases: phase checklist & progress 
  - FILE: `docs/roadmap/phases.md`
- Guidelines & Notes: complexity criteria and decisions 
  - FILE: `docs/roadmap/guidelines.md`
- Changelog: chronological changes 
  - FILE: `docs/roadmap/changelog.md`
- Toast Research: deep-dive on toast patterns & a11y 
  - FILE: `docs/roadmap/toast-research.md`
- Existing Components Snapshot: compact checklists 
  - FILE: `docs/roadmap/existing-components.md`

---

LLM hint: look for the `FILE:` marker then open that path if you need the full section. Each subfile contains the original content extracted from this roadmap.



TechnicalChartView: ✅ Complete — implementation, 94 market tests, browser/accessibility/performance checks, and independent build/Storybook verification passed. See `docs/roadmap/charts-market.md` for the component checklist and counts.

TechnicalChartView usability refinement: ✅ complete; independent build/Storybook, 94 tests and final production browser verification passed. Earnings, OHLC, VPVR, axis badges and oscillator readability are covered.

TechnicalChartView VPVR density refinement: ✅ complete; the default derived profile now uses 24 broader price rows for larger, more legible bars. All 95 market tests, root typecheck, package build and independent Storybook build passed.

TechnicalChartView supplied-results: ✅ Implementation complete (2026-10-15) — controlled producer studies/profiles/VWAP, zero-formula guards, independent light/dark/midnight portals, UTC ranges, geometric history, compact boards, 110 passing market tests, package typecheck/build and scoped Storybook/browser verification. Existing component count is unchanged. Immutable local candidate/publication review is in .chart-supplied-validation; native CommonJS completion now has a verified, explicit peer-boundary repair; see the CommonJS follow-up below. Publication and product installation remain separate gates.

TechnicalChartView CommonJS completion (2026-10-15): ✅ guarded, opt-in repair of the locked lucide-react CJS boundary; native consumer verification and refreshed publication evidence prepared. No dependency version or root lockfile change; component count unchanged.
