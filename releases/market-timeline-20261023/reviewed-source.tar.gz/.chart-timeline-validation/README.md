# Local timeline package candidate

The implementation and local validation are complete. This packet prepares
`aapaetsch-charts-market@0.1.0-beta.3-timeline.1` for local review and sealing.
The version override applies only to the staged package manifest; workspace
manifests, locks, dependencies and versions remain unchanged. Nothing in this
packet authorizes publication, Git writes or Portfolio installation.

`candidate-pointer.json` identifies the exact archive and its SHA-256/SHA-512.
`candidate-seal.json` is the final read-only inventory; a successful seal means
every file matches its hash and has its local write bits removed. This is a local
read-only attribute plus integrity inventory, not an OS immutability guarantee.
The frozen directory includes the npm archive, reviewed source archive, exact
package staging tree, receipt, validation evidence and independent candidate
review. Never replace an existing frozen candidate.

Validation receipts:

- `dev-runner/results.json`, `review.json` and `audit.json`: strict package,
  Storybook and public API types; ESM/CJS/declarations/CSS; 174 Storybook stories;
  84 source-map bindings; seven native entrypoints and eight SSR cases. Nineteen
  affected tests passed on final source. The earlier 257-test/42-file full-suite
  pass is retained with its pre-final-fix qualification; no final259-test claim.
- `browser-results.json`: curated prior-turn observations and thirteen retained
  screenshots, covering 1440x960, 390x844, 320px, compact/multi-pane layouts,
  range labels, right-space pan/reverse, anchored stretch, scale state, delayed
  echoes, updates, drawing priority, touch emulation and nonpositive log handling.
  Actual Chrome200% zoom was verified and restored to100%. Its screenshot and
  desktop/range recordings preceded the final fallback-only repair; other final
  cases followed that build. The interrupted second zoom repetition is not
  claimed. The original browser REPL was lost, so the receipt is reconstructed
  from observed tool outputs and saved PNGs, not a raw-log export or a fresh run.
- `preservation.json`: 5,246 protected original files and Git HEAD unchanged,
  excluding only the five exact owner-approved scope amendments. Old candidates
  and prior release evidence remain intact.

Compatibility is opt-in via `appearance.timeline`/`presentation.timeline`.
Default calendar clamping, text controls and labels stay compatible. Typed
examples/defaults/origin metadata and actual axis/session geometry requirements
are in `charts-market/INTERACTIONS.md`. Saved version-1 state and financial
calculation identities/results remain outside the presentation additions.

Physical iPad Safari/touch and real trackpad acceptance remain separate. Product
exact-version/complete-lock approval, install/rebuild and cached-real verification
are also pending. Public npm publication, trusted CI provenance and consumer
adoption require separate authorization. One pre-existing lint dependency warning
is documented in the validation receipt; there are no lint errors.
