# Workspace interactions (opt in)

`aapaetsch-charts-market` owns navigation and pane gestures. These contracts are runtime presentation state; no provider, formula, acquisition, database or saved-document change is involved. Omit `interactions` to retain existing consumers and Chart Boards calendar behavior.

## Public contracts and callback mapping

All types below are exported from the package root and `/core`. React props are on `TechnicalChartViewProps` and `MarketChartProps`; methods are on `MarketChartHandle` (composite `chartApiRef`, low-level forwarded ref).

| Contract | Purpose / callback |
| --- | --- |
| `MarketChartInteractions` | `{mode: 'workspace', contextKey?: string, rightPaddingBars?: number, scrollOwner?: MarketChartScrollOwner}`. Compressed initial/Fit/Latest padding defaults to ten bars and is clamped to 0–150; pan can explore at most 150 blank slots. Host UTC/calendar domains retain their own geometry. |
| `MarketChartScrollOwner` | `getScrollTop()` and `scrollTo(top)` address the one explicit host workspace scroller. Optional `restoreScrollTop(top)` lets the host retain a restoration request until its intrinsic-height allocation commits. No ancestor lookup or host touch arbitration is needed. |
| `MarketChartInteractionState` | Optional controlled `paneScales: Record<paneId, MarketScaleOptions>` and `maximizedPaneId: string \| null`. Omit the state prop for local composite state. `onInteractionStateChange(next, metadata)` reports temporary values; never persist this object. |
| `MarketViewportCommand` | `{id: string \| number, viewport: MarketViewportOptions}`. Change the id for an external date/reset request, including requests with equal economic bounds. `viewportCommand` works on both components; imperative `setViewportCommand(viewport)` applies immediately. Empty viewport resets to Latest. |
| `resetPaneScale(paneId, metadata?)` | Restore that pane's supplied automatic/fixed domain. Footer Auto/Log and legacy `resetScale()` still address the price pane. Manual ranges are in the scale's transformed domain, retaining its mode and anchor. |
| `onPaneLayoutChange(panes, metadata)` | Composite-only valid local drafts with `phase: 'change'`, final `end`, or `cancel`. Retain the latest draft for Save during a drag; only final changes invoke `onStateChange` to commit pane preferences. Pointer cancellation restores the prior stack without a final intent. |
| `onStateChange(next, metadata)` | Final resize/reorder/collapse updates use existing `TechnicalPaneState`. Map renderer IDs to stable product IDs before saving size/collapse/order. Never save the temporary maximize projection. |
| `onViewportChange` / `onVisibleRangeChange` | Low-level full logical viewport / actual supplied economic bounds. Composite state changes retain logical coordinates. Economic callbacks are suppressed for blank-only views and pane/value-scale/layout actions. Multiple logical positions with equal economic bounds still emit logical state. |
| `MarketChartChangeMetadata` | Distinct `source: 'user' \| 'api' \| 'data' \| 'layout'`, optional gesture, phase and paneId. Gesture kinds include pan/wheel/pinch/time-scale/value-scale/pane-resize/pane-reorder/pane-collapse/pane-maximize/pane-restore/reset. Silent controlled setters do not manufacture user intent. |
| `TechnicalChartGeometry` / `onGeometryChange` | Existing `availableHeight`, `chromeHeight`, `plotHeight`, width and overflow remain. Workspace `renderedPlotHeight` is actual pane-stack/canvas extent (time axis included); `intrinsicHeight` is that extent plus natural chrome. `plotHeight` remains the resolved host available/minimum request. |

## One scroller, hidden inner wrappers and intrinsic allocation

Keep the host's **available-height input independent of its content allocation**. For example, obtain `availableHeight` from the available workspace/card slot. Allocate the hidden inner wrapper from `geometry.intrinsicHeight ?? availableHeight`, while continuing to pass the original available height to `appearance.height`. The package measures natural content independently of that wrapper, so growing at minimums increases the document footprint and maximizing shrinks it without an allocation feedback loop.

```tsx
const owner = React.useMemo<MarketChartScrollOwner>(() => ({
  getScrollTop: () => workspace.current?.scrollTop ?? 0,
  scrollTo: top => { if (workspace.current) workspace.current.scrollTop = top },
  // Optional: retain target until onGeometryChange/host layout has committed.
  restoreScrollTop: top => { pendingRestore.current = top },
}), [])
const interactions = React.useMemo<MarketChartInteractions>(() => ({
  mode: 'workspace', rightPaddingBars: 10, scrollOwner: owner,
}), [owner])

// The sole scroll container belongs to the host; keep a plot-external gutter.
<div ref={workspace} style={{overflowY: 'auto', paddingRight: '1.5rem'}}>
  <div style={{height: geometry?.intrinsicHeight ?? availableHeight, overflow: 'hidden'}}>
    <TechnicalChartView
      {...suppliedChartProps}
      interactions={interactions}
      interactionState={temporaryState}
      onInteractionStateChange={setTemporaryState}
      onPaneLayoutChange={(panes, metadata) => {
        latestDraft.current = panes // Save reads this even during an active drag.
        if (metadata.phase === 'end') commitDisplayPreferences(panes)
      }}
      onGeometryChange={setGeometry}
      appearance={{height: availableHeight, heightMode: 'available',
        minimumPlotHeight: 280, navigation: 'integrated'}}
    />
  </div>
</div>
// In a layout effect after geometry/allocation commits, apply pendingRestore
// to workspace.current.scrollTop and clear it. This performs no chart action.
```

Keep size weights finite in 0.01–1000. In workspace geometry one weight corresponds to 100 CSS pixels before distributing surplus available space; supplied minimums always win. Growing a pane can increase the document instead of squeezing a neighbour below its minimum. Collapsed panes retain a 28px header and reorder through their reachable action menu. Expanded-pane reorder hit areas extend into their own plot, preserving the full 44px target without clipping above the chart or overlapping the next collapsed header. Visible resize and reorder handles have 44px targets; resize occupies the axis edge so it does not cover the next header's controls. Keyboard arrows and menu Grow/Shrink/Move actions are equivalent reachable alternatives. Maximize temporarily projects one expanded pane and disables saved stack mutations; Restore preserves the saved order/weights/collapse state and returns focus and workspace scroll. Removing a maximized pane restores the remaining stack.

## Input ownership and controlled updates

Plot drag pans only time. Plot vertical wheel zooms at its cursor anchor; Shift or dominant horizontal trackpad movement pans. Normalize both axes for pixel/line/page units before classification; ties are vertical. Time-axis drag/wheel scales time (Shift+wheel pans). The actual pane's value axis scales only that pane; Shift+drag translates its manual range. Value-axis double-click resets that pane; time-axis double-click fits history; noninteractive pane-header double-click toggles maximize. Ctrl/Meta+wheel remains browser zoom. Gutter and ordinary chrome scroll the workspace.

A plot touch remains undecided until 8 CSS pixels, then locks horizontal pan or vertical workspace scroll (ties vertical). Two plot fingers pinch around their midpoint and cancel long press/one-finger intent. Remaining fingers cannot resume a pan until a fresh sequence. A stationary 450ms long press inspects exact accepted timestamps; sparse/null studies never substitute neighbours. Axes and handles own immediately. Drawing tools and editable drawing handles retain priority. Pointer cancel, capture loss, blur and unmount clear gesture state/capture/timers without committing a drawing or leaving a pane drag active.

Keep `viewport.logicalRange` separately from clipped economic bounds. Normal controlled echoes acknowledge earlier emitted viewports; they do not move a newer local gesture, including delayed 300ms echoes. Use `viewportCommand` for intentional external Reset/Fit/date selections. Theme, sidebar resize and same-dataset accepted revisions retain historical anchors/manual scales. An optional interactions.contextKey supplies a stable **presentation-only** dataset/source/seed/history context plus layout-load epoch. It does not replace, synthesize or enter dataIdentity, dataRevision, calculationIdentity, financial request keys or atomic bars/results acceptance. Consumers whose canonical calculationIdentity changes on compatible cache-only recalculation should supply this key. Equal context + symbol/interval retains active pane drafts, manual scales and maximize across result identity refreshes; a changed context (or symbol/interval) deliberately resets temporary geometry. Without this opt-in key the existing data identity remains the fallback. Dataset identity, symbol or interval changes deliberately reset temporary geometry; stale data/result acceptance remains guarded by the existing revision contract.

Blank slots contain no OHLC, sessions, generated timestamps, indicator values, crosshair observations or requests. Pane interactions do not change supplied calculation identities, drawing history, warnings, source values or serializer version 1. Existing v1 documents round-trip without new fields. Product persistence, dependency adoption, deployment and acquisition-counter checks belong to the product workstream.

## Validation limits

Use the synthetic Workspace Interactions stories for repeatable input and public snapshots. Automated tests and desktop emulation cannot satisfy physical iPad Safari, real trackpad or physical-device pointer-cancellation acceptance. Those gates remain pending until executed on the actual devices; candidate evidence records precisely what was run. No publication or consumer installation follows from local validation.
# Range-sensitive timeline (opt-in)

Pass `appearance.timeline` to `TechnicalChartView`, or the identical
`presentation.timeline` to `MarketChart`/the engine. These are runtime options,
outside version-1 documents, calculation identities and supplied results.

```tsx
import {
  TechnicalChartView, type MarketTimelinePresentation,
  type MarketSessionRange, type MarketChartSnapshot,
} from 'aapaetsch-charts-market';

const sessions: MarketSessionRange[] = [{
  id: 'producer-session', from: 1773063000, to: 1773086400,
}]; // Host-supplied UTC seconds; never inferred from weekdays or 09:30.
const timeline: MarketTimelinePresentation = {
  range: 'auto', sessions, rightPaddingBars: 10, scaleControls: 'icons',
};
<TechnicalChartView {...suppliedChartProps}
  interactions={{mode: 'workspace', contextKey: 'same-dataset'}}
  appearance={{...appearance, timeline}}
  onStateChange={(next, origin) => {
    // Retain next.viewport.logicalRange on cache-only pan/zoom echoes.
    // Debouncing is supported; external date selection uses viewportCommand.
    saveControlledState(next, origin);
  }} />;
```

Omission preserves legacy calendar clamping, labels and text Auto/Log controls.
An empty `timeline: {}` enables range-sensitive labels and logical right space;
it does not enable icon controls. `range` defaults to `auto`, independent of bar
resolution: <=36 hours selects 1D, <=8 days 5D, <=45 days 1M, <=125 days 3M,
then 6M+. `range: '1D'|'5D'|'1M'|'3M'|'6M'|'1Y'|'all'` is an optional host hint.
The automatic estimate retains the visible logical span when its right portion
is blank; it creates no future timestamp. A fully blank window has no ticks.

1D uses 30-minute wall-clock ticks; 5D uses supplied session starts plus noon
and14:00 within those sessions. Missing `sessions` falls back explicitly to
first/last accepted OHLC observation per display day, never a missing-price
calendar slot or an official session open.
An empty sessions array suppresses that fallback. Intraday labels may interpolate
within supplied display geometry, including missing midday observations, without
creating OHLC rows. 1M/3M prioritize month starts and about every2/5 observed days;
For a calendar axis, include session boundary instants in the supplied `times`
grid when they fall outside observed candle bounds; a session label cannot be
placed beyond its host-owned display geometry. The synthetic fixtures include
these explicit axis-only coordinates, including missing-price session opens.
6M+ uses months and years. Boundaries use the first supplied coordinate of that
period. A year transition takes precedence over month/day/clock labels.
Collision thinning uses measured text width, and repeated clocks during fall DST
are printed once per display day. `timeZone` controls dates and DST; clocks use
24-hour `00:00`, never24:00. Crosshair labels retain date, year, seconds and zone.

`rightPaddingBars` defaults to10, bounded0..150 logical slots. Fit/Home show the
supplied domain plus this padding. Latest preserves horizontal span and returns
to the padded end; if the span is wider than that fitted domain, Latest restores
the fitted view instead of retaining extra blank space.
Plot pan may use up to150 additional slots, retaining zoom and manual value
scales; a fully blank window retains the last automatic domains too. No new
economic bounds, observation, session or earnings date is inferred there.
Explicit supplied future calendar anchors remain available to earnings/drawings.
Calendar updates preserve the logical window, remapping a known left anchor when
needed, and same-context data revisions/resize preserve it. Use a new contextKey
for a true dataset replacement. Existing gesture ownership/cancellation remains
shared: plot pan, bottom-axis stretch around its starting anchor, value-axis
scale, drawing hits and workspace scroll. Shift+Left/Right pans; +/- zoom; Home
fits and End returns to Latest. Ctrl/Meta browser shortcuts remain untouched.

`onVisibleRangeChange` emits only changed accepted OHLC bounds in this mode;
empty windows do not fabricate an economic range. `onViewportChange` carries
logical geometry even for calendar/UTC axes and can carry no visibleRange in
blank space. Old logical or economic-only acknowledgements are ignored; explicit
`viewportCommand` remains authoritative. Metadata uses existing `source`,
`gesture` (`pan`, `time-scale`, `keyboard`, etc.) and `phase` fields. Scale,
chrome, tick/padding configuration and layout edits emit no economic callback.
Hosts must treat these callbacks as cache-only navigation, never provider intent.

With `scaleControls:'icons'` the engine reserves an88CSSpx price-axis lane and
the composite puts two44CSSpx targets beneath it. Icons remain1rem; pressed
state, distinct icons, accessible names, focus rings and current-state tooltips
identify Auto/manual and linear/log. Host status/timezone/actions wrap to the
left. Native axis gestures/reset update the live snapshot used by these controls;
log switches retain nonpositive-value errors and clear stale manual overrides.
Alternative engines can return these optional read-only snapshot fields:

```ts
function observe(snapshot: MarketChartSnapshot) {
  snapshot.priceAxis; // {left,width,surfaceWidth,side} in surface-local CSS px
  snapshot.scale;     // actual price mode/autoScale/manualRange
  snapshot.timeTicks; // readonly MarketTimeTick[]: time,x,label,left,width,kind,source
}
// <MarketChart {...props} presentation={{timeline}} onSnapshotChange={observe}/>
```

The snapshot callback uses a current ref, retains the engine instance, and runs
after scale/layout/tick resolution. It may fire for inspection; deduplicate the
fields you consume instead of setting an entire snapshot into props each frame.
Custom snapshots may omit the new fields; icon layout then uses an88px fallback.
For accurate custom-engine alignment, return an88px priceAxis lane. Original
snapshots and custom engines remain type-compatible. No product DOM selectors
or second gesture implementation is needed. Synthetic stories live under
**Market Charts / Timeline Controls**. Physical-device and product adoption
verification remain separate from upstream browser emulation.

