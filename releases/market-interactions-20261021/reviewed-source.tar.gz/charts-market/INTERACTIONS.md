# Workspace interactions (opt in)

`aapaetsch-charts-market` owns navigation and pane gestures. These contracts are runtime presentation state; no provider, formula, acquisition, database or saved-document change is involved. Omit `interactions` to retain existing consumers and Chart Boards calendar behavior.

## Public contracts and callback mapping

All types below are exported from the package root and `/core`. React props are on `TechnicalChartViewProps` and `MarketChartProps`; methods are on `MarketChartHandle` (composite `chartApiRef`, low-level forwarded ref).

| Contract | Purpose / callback |
| --- | --- |
| `MarketChartInteractions` | `{mode: 'workspace', contextKey?: string, rightPaddingBars?: number, scrollOwner?: MarketChartScrollOwner}`. Compressed initial/Fit/Latest padding defaults to ten bars and is clamped to 0–150; pan can explore at most 150 blank slots. Host UTC/calendar domains retain their own geometry. |
| `MarketChartScrollOwner` | `getScrollTop()` and `scrollTo(top)` address the one explicit host workspace scroller. Optional `restoreScrollTop(top)` lets the host retain a restoration request until its intrinsic-height allocation commits. No ancestor lookup or host touch arbitration is needed. |
| `MarketChartInteractionState` | Optional controlled `paneScales: Record<paneId, MarketScaleOptions>` and `maximizedPaneId: string \| null`. Omit the state prop for local composite state. `onInteractionStateChange(next, metadata)` reports temporary values; never persist this object. |
| `MarketViewportCommand` | `{id: string \| number, viewport: MarketViewportOptions}`. Change the id for an external date/reset request, including requests with equal economic bounds. `viewportCommand` works on both components; imperative `setViewportCommand(viewport)` applies immediately. Empty viewport resets to Latest. |
| `resetPaneScale(paneId, metadata?)` | Restore that pane's supplied automatic/fixed domain. Footer Auto/Log and legacy `resetScale()` still address the price pane. Manual ranges are in the scale's transformed domain, retaining its mode and anchor. |
| `onPaneLayoutChange(panes, metadata)` | Composite-only valid local drafts with `phase: 'change'`, final `end`, or `cancel`. Retain the latest draft for Save during a drag; only final changes invoke `onStateChange` to commit pane preferences. Pointer cancellation restores the prior stack without a final intent. |
| `onStateChange(next, metadata)` | Final resize/reorder/collapse updates use existing `TechnicalPaneState`. Map renderer IDs to stable product IDs before saving size/collapse/order. Never save the temporary maximize projection. |
| `onViewportChange` / `onVisibleRangeChange` | Low-level full logical viewport / actual supplied economic bounds. Composite state changes retain logical coordinates. Economic callbacks are suppressed for blank-only views and pane/value-scale/layout actions. Multiple logical positions with equal economic bounds still emit logical state. |
| `MarketChartChangeMetadata` | Distinct `source: 'user' \| 'api' \| 'data' \| 'layout'`, optional gesture, phase and paneId. Gesture kinds include pan/wheel/pinch/time-scale/value-scale/pane-resize/pane-reorder/pane-collapse/pane-maximize/pane-restore/reset. Silent controlled setters do not manufacture user intent. |
| `TechnicalChartGeometry` / `onGeometryChange` | Existing `availableHeight`, `chromeHeight`, `plotHeight`, width and overflow remain. Workspace `renderedPlotHeight` is actual pane-stack/canvas extent (time axis included); `intrinsicHeight` is that extent plus natural chrome. `plotHeight` remains the resolved host available/minimum request. |

## One scroller, hidden inner wrappers and intrinsic allocation

Keep the host's **available-height input independent of its content allocation**. For example, obtain `availableHeight` from the available workspace/card slot. Allocate the hidden inner wrapper from `geometry.intrinsicHeight ?? availableHeight`, while continuing to pass the original available height to `appearance.height`. The package measures natural content independently of that wrapper, so growing at minimums increases the document footprint and maximizing shrinks it without an allocation feedback loop.

```tsx
const owner = React.useMemo<MarketChartScrollOwner>(() => ({
  getScrollTop: () => workspace.current?.scrollTop ?? 0,
  scrollTo: top => { if (workspace.current) workspace.current.scrollTop = top },
  // Optional: retain target until onGeometryChange/host layout has committed.
  restoreScrollTop: top => { pendingRestore.current = top },
}), [])
const interactions = React.useMemo<MarketChartInteractions>(() => ({
  mode: 'workspace', rightPaddingBars: 10, scrollOwner: owner,
}), [owner])

// The sole scroll container belongs to the host; keep a plot-external gutter.
<div ref={workspace} style={{overflowY: 'auto', paddingRight: '1.5rem'}}>
  <div style={{height: geometry?.intrinsicHeight ?? availableHeight, overflow: 'hidden'}}>
    <TechnicalChartView
      {...suppliedChartProps}
      interactions={interactions}
      interactionState={temporaryState}
      onInteractionStateChange={setTemporaryState}
      onPaneLayoutChange={(panes, metadata) => {
        latestDraft.current = panes // Save reads this even during an active drag.
        if (metadata.phase === 'end') commitDisplayPreferences(panes)
      }}
      onGeometryChange={setGeometry}
      appearance={{height: availableHeight, heightMode: 'available',
        minimumPlotHeight: 280, navigation: 'integrated'}}
    />
  </div>
</div>
// In a layout effect after geometry/allocation commits, apply pendingRestore
// to workspace.current.scrollTop and clear it. This performs no chart action.
```

Keep size weights finite in 0.01–1000. In workspace geometry one weight corresponds to 100 CSS pixels before distributing surplus available space; supplied minimums always win. Growing a pane can increase the document instead of squeezing a neighbour below its minimum. Collapsed panes retain a 28px header and reorder through their reachable action menu. Expanded-pane reorder hit areas extend into their own plot, preserving the full 44px target without clipping above the chart or overlapping the next collapsed header. Visible resize and reorder handles have 44px targets; resize occupies the axis edge so it does not cover the next header's controls. Keyboard arrows and menu Grow/Shrink/Move actions are equivalent reachable alternatives. Maximize temporarily projects one expanded pane and disables saved stack mutations; Restore preserves the saved order/weights/collapse state and returns focus and workspace scroll. Removing a maximized pane restores the remaining stack.

## Input ownership and controlled updates

Plot drag pans only time. Plot vertical wheel zooms at its cursor anchor; Shift or dominant horizontal trackpad movement pans. Normalize both axes for pixel/line/page units before classification; ties are vertical. Time-axis drag/wheel scales time (Shift+wheel pans). The actual pane's value axis scales only that pane; Shift+drag translates its manual range. Value-axis double-click resets that pane; time-axis double-click fits history; noninteractive pane-header double-click toggles maximize. Ctrl/Meta+wheel remains browser zoom. Gutter and ordinary chrome scroll the workspace.

A plot touch remains undecided until 8 CSS pixels, then locks horizontal pan or vertical workspace scroll (ties vertical). Two plot fingers pinch around their midpoint and cancel long press/one-finger intent. Remaining fingers cannot resume a pan until a fresh sequence. A stationary 450ms long press inspects exact accepted timestamps; sparse/null studies never substitute neighbours. Axes and handles own immediately. Drawing tools and editable drawing handles retain priority. Pointer cancel, capture loss, blur and unmount clear gesture state/capture/timers without committing a drawing or leaving a pane drag active.

Keep `viewport.logicalRange` separately from clipped economic bounds. Normal controlled echoes acknowledge earlier emitted viewports; they do not move a newer local gesture, including delayed 300ms echoes. Use `viewportCommand` for intentional external Reset/Fit/date selections. Theme, sidebar resize and same-dataset accepted revisions retain historical anchors/manual scales. An optional interactions.contextKey supplies a stable **presentation-only** dataset/source/seed/history context plus layout-load epoch. It does not replace, synthesize or enter dataIdentity, dataRevision, calculationIdentity, financial request keys or atomic bars/results acceptance. Consumers whose canonical calculationIdentity changes on compatible cache-only recalculation should supply this key. Equal context + symbol/interval retains active pane drafts, manual scales and maximize across result identity refreshes; a changed context (or symbol/interval) deliberately resets temporary geometry. Without this opt-in key the existing data identity remains the fallback. Dataset identity, symbol or interval changes deliberately reset temporary geometry; stale data/result acceptance remains guarded by the existing revision contract.

Blank slots contain no OHLC, sessions, generated timestamps, indicator values, crosshair observations or requests. Pane interactions do not change supplied calculation identities, drawing history, warnings, source values or serializer version 1. Existing v1 documents round-trip without new fields. Product persistence, dependency adoption, deployment and acquisition-counter checks belong to the product workstream.

## Validation limits

Use the synthetic Workspace Interactions stories for repeatable input and public snapshots. Automated tests and desktop emulation cannot satisfy physical iPad Safari, real trackpad or physical-device pointer-cancellation acceptance. Those gates remain pending until executed on the actual devices; candidate evidence records precisely what was run. No publication or consumer installation follows from local validation.
