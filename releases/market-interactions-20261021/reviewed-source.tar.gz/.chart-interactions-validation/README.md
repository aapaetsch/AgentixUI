# Workspace interaction candidate

Scoped local implementation of the October 21 My Charts interaction supplement.
Writes are limited to `charts-market/`, `docs/ROADMAP.md`, and this directory.
Portfolio and OpenBB remain read-only. Existing published archives are preserved.

The candidate adds opt-in shared input routing, explicit one-owner touch scroll,
independent temporary pane scales, bounded compressed right padding, pane workflow,
logical controlled acknowledgements, natural intrinsic geometry, and a presentation
context key independent of canonical financial result identity.

`PUBLIC_API.md` maps the actual public exports and host responsibilities.
`REVIEW.md` records final candidate identity and executed/pending acceptance.
`dev-runner/final-results.json` and `final-audit.json` bind current source and dist.
`browser-results.json` records executed browser input/layout checks and limitations.
`traces/` contains repeatable input parameters and a main-thread callback trace.
`candidates/` holds a separately reviewed source archive and exact offline npm pack.

No dependency installation/download, publication, commit, push, PR, product edit,
provider request, database operation or cross-chat message is authorized by this
implementation request. Local preparation does not approve publication or adoption.

Physical iPad Safari, real trackpad, physical cancellation, and product/account/data
acceptance remain downstream gates. Synthetic observations do not satisfy them.
