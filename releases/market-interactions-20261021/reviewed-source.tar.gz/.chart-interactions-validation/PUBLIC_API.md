# Public consumer contract

The package root and `/core` export `MarketChartInteractions`,
`MarketChartScrollOwner`, `MarketChartInteractionState`,
`MarketChartInteractionChange`, and `MarketViewportCommand`. Existing
`MarketChartChangeMetadata` and `TechnicalChartGeometry` gain optional fields.
The root still re-exports the component/handle types. Native ESM and CJS entrypoints
remain root, core, indicators, drawings, overlays, controls, workspace; CSS remains
`aapaetsch-charts-market/styles.css`.

| Host boundary | Actual API and mapping |
| --- | --- |
| Opt in | `interactions={{mode:'workspace', rightPaddingBars:10, contextKey, scrollOwner}}` on `TechnicalChartView` or `MarketChart`. Omit for legacy behavior. |
| One scroller | `scrollOwner.getScrollTop()` / `.scrollTo(top)`; optional `.restoreScrollTop(top)` defers restoration until host allocation commits. No ancestor discovery or duplicate host gesture arbitration. |
| Compatible result refresh | `contextKey` is presentation-only, stable across compatible same-history recalculation and changed for true listing/interval/source/seed/history/layout-load replacement. Financial identities remain unchanged and still validate bars/results. |
| Temporary state | `interactionState` and `onInteractionStateChange(next, metadata)` control manual `paneScales` and `maximizedPaneId`. Never serialize this state into financial or saved layout definitions. |
| Pane drafts/save | `onPaneLayoutChange(panes, metadata)` exposes valid change/end/cancel drafts, including Save during drag. Only final resize commits invoke existing `onStateChange`; map renderer IDs to stable product IDs. |
| Reset scales | Handle `resetPaneScale(id, metadata?)`; footer Auto/Log and legacy price methods retain price-only semantics. |
| Explicit date/reset | `viewportCommand={{id,viewport}}` or handle `.setViewportCommand(viewport)`. Id change distinguishes a command from a delayed controlled acknowledgement. |
| Viewport | Retain full `viewport.logicalRange`; low-level `onViewportChange` includes logical state even with unchanged clipped economic bounds. `onVisibleRangeChange` returns actual accepted bar bounds and is suppressed for blank-only views. |
| Origins | `source: user/api/data/layout`; gesture, paneId, phase start/change/end/cancel. Pane/layout/value-scale actions emit no economic acquisition intent. |
| Intrinsic footprint | `onGeometryChange` reports actual `renderedPlotHeight` (time axis included) and natural `intrinsicHeight`. Allocate hidden wrappers from intrinsic height while keeping `appearance.height` equal to the independent available slot. |

The strict public-import example is
`charts-market/examples/workspace-interactions.tsx`. Full type definitions,
one-scroller example, scale coordinates and controlled lifecycle are documented in
the packed `INTERACTIONS.md`. `TechnicalPaneState.size` remains a finite display
weight (0.01–1000); collapsed state/order use the existing fields. No serializer
version or mandatory persisted field changes.

Supplied mode remains mandatory for Portfolio: this work adds no financial formula,
provider/acquisition path, producer key or invented blank-space observation. Prior
calendar, adaptive width, endpoint boxes, drawings/history and identity acceptance
remain covered by existing regression suites.

Portfolio continuation requires its own review of exact npm version/integrity and
complete lock, scripts-disabled dependency installation, stable product pane-ID
mapping, explicit save/revision/conflict/RLS flows, integrated footer composition,
and acquisition-counter checks across every supported chart path. Publication and
adoption have not occurred for this candidate.
