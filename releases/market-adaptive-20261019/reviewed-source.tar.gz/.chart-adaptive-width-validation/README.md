# Adaptive candle and volume widths: local review

This scoped follow-up implements the owner-approved matching candle/volume slot geometry. Configure both with `{widthMode: 'adaptive', gap: 2}` through existing appearance/presentation APIs. Historical defaults and compact-board behavior remain unchanged. Read `PUBLIC_API.md` and `charts-market/ADAPTIVE-WIDTHS.md` for precise precedence, validation and dense/DPI limits.

Evidence is kept under this directory only:

- `dev-runner/baseline.json`: initial dirty source, dependencies/root UI/icons and sealed prior readability artifact identities.
- `dev-runner/final-results.json` / `final-audit.json`: independent tests, strict types/examples, lint, ESM/CJS/CSS build, Storybook, public exports and scope/guard receipts.
- `browser-results.json`, `browser-cases.json`, `browser-public-snapshots.json`: actual synthetic browser cases, public geometry/readout observations and limitations.
- `screenshots/`: comparisons, overlay/dedicated/line volume, sparse/dense/fractional, narrow/multi-chart and runtime/native-DPI evidence.
- `candidates/adaptive-<source hash>/receipt.json`: immutable local package/source/evidence binding. Candidate files are read-only and must never be overwritten.

The isolated candidate version is `aapaetsch-charts-market@0.1.0-beta.3-adaptive.1`. It includes prior readability/supplied work; the previous candidate remains sealed. No root manifest/lock, product, OpenBB or other repository was modified. No downloads, installations, provider/database operations, publication, deployment, financial release, commits, pushes, pull requests or outgoing chat messages are authorized or performed.

Exact package SHA256/SHA512, source binding, file inventory and executed checks are in the candidate receipt and independent review. Local package smoke checks use approved installed peers; no fresh React18 or real product cached-data acceptance is claimed. Browser validation uses synthetic data and Chromium viewport/DPI emulation; physical mobile/Safari acceptance remains a consumer follow-up. Automatic publication/provenance is not implied by local packing.
