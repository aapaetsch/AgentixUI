# Adaptive candle and volume widths

Write allowlist: charts-market/, docs/ROADMAP.md, .chart-adaptive-width-validation/. Preserve all existing dirty readability work and prior immutable candidates. No downloads, publication, product/OpenBB writes, provider/database calls, commits, pushes, PRs or messages to other chats.

No TODO-list tool is exposed; this file tracks the required task list.

- [x] Read the complete owner request, applicable agents instructions and read-only consumer evidence.
- [x] Record initial dirty/source/dependency identities and preserve the previous candidate.
- [x] Implement opt-in validated candle/volume adaptive geometry with shared centering, dense/DPI policy and unchanged defaults.
- [x] Add synthetic stories and meaningful geometry/public-forwarding/runtime/identity regressions.
- [x] Run Dev Runner tests, strict public types, build, Storybook and independent review; fix findings.
- [x] Verify desktop/narrow/multi-chart/high-DPI behavior and pan/zoom/resize through the browser.
- [x] Document exact API, precedence, degradation and limits; update ROADMAP.
- [x] Freeze and independently verify a separately identifiable immutable local candidate and evidence.
