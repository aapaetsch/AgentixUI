# Adaptive width API and compatibility

```ts
interface MarketChartPresentation {
  candles?: {
    widthMode?: 'proportional' | 'adaptive';
    gap?: number; // CSS px, finite 0..32 inclusive; adaptive default 2
    bodyRatio?: number; // existing, proportional only
    maximumWidth?: number; // existing, proportional only
    wickWidth?: number; // existing, bounded inside adaptive body footprint
  };
  volume?: {
    widthMode?: 'proportional' | 'adaptive';
    gap?: number; // CSS px, finite 0..32 inclusive; adaptive default 2
  };
  // All prior presentation fields remain.
}
```

Forwarded through `TechnicalChartView.appearance`, `MarketChart.presentation`, engine creation and `setPresentation`. An optional `MarketSeriesRendererContext.pixelRatio` gives custom renderers the backing-store ratio; external calls omitting it retain a ratio of 1. The geometry helper stays internal. No new mandatory API, dependency, serialized field or calculation identity is introduced.

Omitted/explicit proportional mode preserves historical behavior: candle ratio0.7/cap14/minimum1CSSpx with floor, volume ratio0.7/cap12/minimum1CSSpx. Existing candle ratio/cap overrides still work in proportional mode. Adaptive mode ignores those caps/ratios and uses the nominal time-scale slot, never the next observed bar distance.

For slot spacing S, gap G and Canvas DPR R>=1: width=min(S,max(1/R,S-G)), left=timestampCoordinate-width/2. Equal configured gaps share exact fractional CSS edges across candles and all volume panes. Target gap holds where S>=G+1/R; dense slots use one physical pixel, or subpixel slot width when even that cannot fit. No independent integer rounding; fractional antialiasing and physical-pixel aggregation remain display limitations. Adaptive hollow borders/wicks remain inside the body footprint and flat one-pixel bodies remain visible.

Source bars, supplied formula/runtime bypass, request keys, version-1 documents, controlled histories, clipping, volume heights/baselines/units, colors/opacity and exact evidence stay unchanged. Compact Chart Boards inherit legacy geometry unless a host separately opts them in; this task makes no consumer edits.

See `charts-market/ADAPTIVE-WIDTHS.md` and strict public-entrypoint example `charts-market/examples/adaptive-supplied-chart.tsx`. The candidate includes the earlier locally reviewed readability work and preserves its separate sealed artifact. Workspace version/root lock remain unchanged; only the isolated candidate manifest uses `0.1.0-beta.3-adaptive.1`.

Publication, exact npm artifact/complete-lock human dependency approval, product installation/rebuilt-stack/browser acceptance and financial release are separate gates. No publication or remote handoff is authorized here.
