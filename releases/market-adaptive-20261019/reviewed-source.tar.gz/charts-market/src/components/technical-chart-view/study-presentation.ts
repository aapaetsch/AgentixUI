import {marketTimeKey, type IndicatorDefinition, type IndicatorRenderSeries, type MarketTime, type TechnicalChartViewState} from '../../core';

type Study = TechnicalChartViewState['indicators'][number];
/** Use public definition metadata, never parse an instance ID into visible copy. */
export function studyLabel(instance: Study, definition?: IndicatorDefinition): string {
  if (!definition) return 'Unavailable study';
  const parameters = definition.formatParameters?.(instance.parameters) ?? Object.values(instance.parameters)
    .filter(value => typeof value === 'number' || typeof value === 'string' || typeof value === 'boolean')
    .map(String).join(', ');
  return [definition.label, parameters].filter(Boolean).join(' ');
}
export function studyLabels(instances: readonly Study[], definitions: readonly IndicatorDefinition[]): Map<string, string> {
  const names = instances.map(instance => studyLabel(instance, definitions.find(definition => definition.id === instance.definitionId)));
  const totals = new Map<string, number>();
  names.forEach(name => totals.set(name, (totals.get(name) ?? 0) + 1));
  const seen = new Map<string, number>();
  return new Map(instances.map((instance, i) => {
    const name = names[i], ordinal = (seen.get(name) ?? 0) + 1; seen.set(name, ordinal);
    return [instance.id, totals.get(name)! > 1 ? `${name} · ${ordinal}` : name];
  }));
}
/** Exact-time binary lookup. Sparse/missing samples remain unavailable, never carried forward. */
export function studyValueAt(points: Readonly<IndicatorRenderSeries['points']>, time?: MarketTime): number | null {
  if (time == null) return null;
  const key = marketTimeKey(time); let low = 0, high = points.length;
  while (low < high) {const mid = (low + high) >>> 1; if (marketTimeKey(points[mid].time) < key) low = mid + 1; else high = mid;}
  const point = points[low];
  return point && marketTimeKey(point.time) === key && point.value != null && Number.isFinite(point.value) ? point.value : null;
}
export function readableValue(value: number | null, locale?: string, formatter?: (value: number) => string): string {
  return value == null ? '—' : formatter?.(value) ?? new Intl.NumberFormat(locale, {maximumFractionDigits: 4, maximumSignificantDigits: 6}).format(value);
}
