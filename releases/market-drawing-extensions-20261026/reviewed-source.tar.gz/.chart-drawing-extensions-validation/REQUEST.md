# Line extensions and future drawing space

Prepared and sent October 26, 2026, after explicit owner authorization, to existing
UI-kit chart chat `01a140c1-e3d6-7182-b4f8-735c6a258a5b`. Delivery was confirmed by
the chat messaging tool.
Shared implementation, publication and exact dependency adoption remain pending.

Product: [My Charts](http://localhost:3000/my-charts), authenticated. The running
Compose frontend port was checked as `127.0.0.1:3000`. This request requires no
source acquisition, new market history, calculation changes or database operation.

## Requested outcome

- Select a line and independently toggle **Extend left** and **Extend right**.
  A trend line can remain a segment, become a ray in either direction, or extend
  both ways without changing its two saved anchors.
- Pan a one-year chart until roughly six months of history remain visible, then
  draw from that history into blank space at least another year into the future.
  Future month/year labels and the precise crosshair date make the scale clear.
- Create, move, resize, select, undo and redo drawings in that space; reopen the
  same account/listing document and retain the exact dates and extension settings.

These are renderer presentation capabilities. Product authorization, private
autosave, currency/basis validation and Decimal anchor persistence remain owned
by PortfolioTrackAndScreen. This supplements the delivered timeline interaction
work; it must preserve its gestures, controlled echoes and supplied-only mode.

## Inspected evidence

Product files, read-only for the receiving UI-kit task:

- `frontend/lib/market-chart-adapter.ts`: `marketState` sets right-offset bounds
  to zero; `marketDrawings` and `productDrawings` round-trip color/width but no
  extension flags. Unchanged anchors preserve original Decimal strings.
- `frontend/lib/chart-settings.ts`: `GeometricDrawing` and `validDrawingMap`
  accept only the existing bounded drawing fields.
- `backend/src/portfolio_platform/charts/workspace.py`: strict `GeometricDrawing`
  validation must separately adopt any optional persisted extension fields.
- `frontend/components/first-party-market-chart.tsx`: public supplied renderer,
  timeline padding of ten slots, external geometric rail and shared history
  commands. `frontend/lib/chart-viewport.ts` retains logical geometry across
  controlled acknowledgements and compatible history updates.
- `frontend/components/chart-drawing-editor.tsx`: manual account drawing editor;
  a later product update must preserve extension flags when editing other fields.
- `docs/architecture/chart-drawing-autosave.md`: private revisioned documents,
  conflict reconciliation, account disposal and layout-independent persistence.

UI-kit evidence at `C:/Users/aapae/Documents/Projects/Aidans-React-UI`:

- `charts-market/src/engine/time-scale.ts`: timeline `logicalToTime` returns null
  beyond supplied geometry; calendar `timeToLogical` rejects outside-grid times.
- `charts-market/src/engine/time-ticks.ts`: supplied timeline tick selection.
- `charts-market/src/drawings/index.ts`: trend lines have no extension schema;
  channel/Fibonacci extension options are not a public trend-line solution.
- `charts-market/src/drawings/geometry.ts` and `drawing-layer.tsx`: shared drawing
  geometry, hit testing, editing and contextual toolbar boundaries.
- `charts-market/src/components/technical-chart-view/`: controlled composition.
- Published `INTERACTIONS.md`: right padding is bounded to 150 slots, blank space
  creates no timestamp and a fully blank window has no ticks. That is inadequate
  for the requested one-year drawing horizon on a daily or intraday chart.

The active version/artifact is governed exclusively by product dependency records.
Do not patch installed packages or implement a parallel product drawing engine.

## Shared behavior and public contract

### Line extensions

Add typed, serializable independent extension flags for the supplied-mode trend
line. Prefer optional `extendLeft` / `extendRight` parameters, defaulting false
for old trend-line documents. Left/right mean chronological screen direction,
including when the user originally drew the anchors in reverse order. Extend the
line to the visible price-pane boundary and clip it; do not move saved anchors.
Rendering and hit testing must agree on the extended body. Retain endpoint handles
at the actual anchors and keep offscreen anchors editable after reverse panning.
Handle equal-time, horizontal and reversed anchors without NaN or infinite output.

Also support directional horizontal lines if compatible with the audited supplied
tool: legacy horizontal lines retain their full-width appearance by default;
left/right then apply relative to their one anchor. Specify the both-off rendering
and serialization behavior explicitly and keep an accessible selection target.
Vertical lines and rectangles do not gain irrelevant extension controls.

Use the existing contextual toolbar with two labeled, keyboard-operable controls,
pressed/checked state, tooltips, focus indication and touch targets. Each completed
toggle emits one existing drawing-style transaction, integrates with shared undo/
redo and does not replace the drawing ID. Return documented public types and
controlled examples; the product must not infer undocumented parameter behavior.

### Future display dates and drawing coordinates

Provide an opt-in, bounded public future-display policy and coordinate mapping
that works with provider-daily, session-rollup and supplied calendar/UTC axes.
The product must be able to permit at least twelve calendar months beyond the
last supplied observation; a hard 150-slot ceiling is insufficient. Supply an
explicit configurable horizon and sensible finite defaults. Preserve old consumer
behavior unless opted in. Do not force a large blank margin on the initial view.

Future dates are a display ruler for authored drawings, never observations or
predicted trading sessions. Define the extension's calendar-time convention,
interval spacing, timezone and transition from known compressed geometry. Return
the exact policy/API for review; do not infer exchange opens, holidays or future
sessions. If actual future trading-session spacing requires unavailable calendar
evidence, provide the documented calendar-time display alternative. No product
calendar generator or provider request is part of this work.

Drawing time-to-coordinate and coordinate-to-time conversions must agree in that
extension, including after pan, zoom, resize and controlled echoes. Do not clamp a
future anchor to the final candle. Future ticks use the same mapping, with readable
month/year boundaries for long spans and precise dates on inspection. Empty future
windows retain date ticks and drawings. Observed readouts remain unavailable there;
do not repeat the last OHLC/study value as if it occurred at the future timestamp.
Keep supplied earnings anchors exact and avoid any extension-policy rewrite of them.

Panning exposes blank space; the normal drawing tool can then place anchors there.
The pointer need not leave the chart DOM. Preserve drawing/handle priority over
plot panning, axis stretching, touch scrolling and pinch. Cancel/blur/unmount must
not create a drawing or leave capture active. Preserve manual price scales and
existing Fit/Home/Latest behavior, documenting any explicit future-view reset.

Logical viewport callbacks may describe future presentation space. Economic
visible-range callbacks remain bounded to accepted observations, or absent for an
empty future view. No future display date may extend saved acquisition/seed bounds,
trigger indicator/provider requests, fabricate bars, enter a dataset manifest or
become an authoritative financial value. Existing supplied results remain bytewise
unchanged. Geometric line interpolation is authored annotation only.

## Authorized receiver write and operational scope

The owner-authorized implementation request permits exhaustive writes within
`C:/Users/aapae/Documents/Projects/Aidans-React-UI` are:

- `charts-market/src/engine/`
- `charts-market/src/core/time-axis.ts`
- `charts-market/src/drawings/`
- `charts-market/src/components/technical-chart-view/`
- `charts-market/src/types.ts`
- `charts-market/src/index.ts`
- `charts-market/src/react.ts`
- `charts-market/README.md`
- `charts-market/INTERACTIONS.md`
- `charts-market/CALENDAR-COORDINATES.md`
- `docs/ROADMAP.md`
- `.chart-drawing-extensions-validation/`

Read nearest AGENTS before writing; missing listed files need not be created.
Everything else, including root manifests/locks, versions, product/OpenBB code and
private data, remains read-only. Propose an exact scope amendment before exceeding
this list. Use installed approved dependencies, focused tests and required Dev
Runner/Storybook validation. Return reviewable source, a sealed candidate, public
integration examples, compatibility notes and actual validation evidence.
Publication, downloads, commits/pushes/PRs, cross-chat messages, service changes
and database/source actions require separate authorization.

## Acceptance and later product adoption

Upstream synthetic supplied fixtures must cover all four trend extension states,
reverse anchors, equal-time/horizontal lines, body hits, offscreen anchors, future
creation/drag/handle/keyboard edits, undo/redo and serialization. Cover daily,
weekly, monthly and intraday axes, sparse/one/empty data, existing future earnings,
year/month boundaries, leap day, DST and both dark/light themes. Exercise a 1Y
view panned to six months of history plus at least one future year, including a
fully future viewport, controlled echoes, data append/retention, resize, cancellation
and bounded horizon behavior. Verify no source or supplied-calculation changes.
Inspect desktop, 390px/320px widths, touch emulation and 200% zoom; distinguish
physical-device evidence from emulation.

After a reviewed public API and separately approved exact publication/lock/install,
the product will add optional strictly validated extension settings to backend and
frontend documents, preserve old defaults and Decimal anchor bytes, update adapter
round-trips/manual edits, and compose future-display support through public APIs.
Existing JSON persistence needs no migration unless a concrete constraint proves
otherwise. Cover autosave/reopen, conflicts, undo/redo and two-account isolation.
Run focused backend drawing tests, frontend core/typecheck/build, rebuild the local
stack and inspect cached-real desktop/narrow My Charts with no source acquisition.
This handoff alone does not implement, deploy or establish browser acceptance.
