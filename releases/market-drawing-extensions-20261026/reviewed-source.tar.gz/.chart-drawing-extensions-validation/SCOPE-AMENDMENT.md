# Owner-approved scope amendment

October 26, 2026: the owner answered **Approve these two paths** to add:

- `charts-market/src/core/types.ts`: a typed display-only future inspection, separate from economic crosshair/bar snapshots.
- `charts-market/src/components/market-chart/index.tsx`: forward future inspection to the existing controlled renderer/readout path.

Reason: the exhaustive request excludes these paths, but future readouts must be
unavailable rather than silently falling back to the latest observed candle.
All original operational and write restrictions otherwise remain in effect.
