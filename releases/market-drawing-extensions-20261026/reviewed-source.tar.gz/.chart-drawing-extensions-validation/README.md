# Local drawing-extension candidate

Implements the October 26 owner-authorized Portfolio request, with the two-path
amendment recorded in SCOPE-AMENDMENT.md. Product files are read-only evidence.

Public contracts and examples are in charts-market/INTERACTIONS.md and
charts-market/CALENDAR-COORDINATES.md. Source includes eleven synthetic supplied
Storybook cases and focused geometry/editing tests. Independent Dev Runner
evidence and browser receipts bind the final source/build before sealing.

This directory owns all new output and caches. Root/package manifests, dependency
versions, locks, existing dist, prior validation roots and sealed packages remain
protected. There is no publication, package download/install, Git mutation,
provider/database/service change or outgoing cross-chat message in this task.

The local candidate retains the existing workspace version for review only; a
release version and exact publication are separate owner-authorized actions.
Physical touch hardware, screen-reader speech and Portfolio private persistence,
account isolation, deployment and cached-real consumer acceptance remain consumer
gates; desktop, narrow and touch-emulation evidence is described literally.
