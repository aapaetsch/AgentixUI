# Earnings timeline edge pins

Implementation/review scope: seven named source/doc files and this validation
directory only. Existing pane/interaction work is part of the source baseline.
No product, OpenBB, financial/account data or dependency files are writable.

The old guard discarded the first/last fitted coordinates and a 12px interior
strip. `earningsPinLeft` first checks the unchanged coordinate against inclusive
plot bounds, then moves only the native 24px button inside the plot with 2px focus
ring clearance. Invalid/off-screen/unresolved coordinates remain absent. Explicit
`barTime`, supplied event data, calendar geometry and price rows are unchanged.

The existing Tooltip and shared earnings Dialog remain the interaction. Marker
click records its trigger so dismiss returns focus when that marker remains in
the document. The helper is internal; no root export, public event/serializer or
financial calculation contract is added.

The supplied reference describes E icons on the report-date X coordinate:
[TradingView earnings](https://www.tradingview.com/support/solutions/43000629790-earnings/).
This fix uses the native renderer and existing supplied EPS fields. It does not
adopt provider inference or calculate surprise values.

Evidence includes the preservation baseline/diff, failing-before regression,
installed-tool Dev Runner results, browser screenshots and a sealed local npm
candidate. Synthetic test/story calendars are clearly labeled fixtures and never
enter any product data. Actual private announcement dates remain read-only.

Physical iPad Safari/trackpad acceptance from the interaction release remains
pending. Synthetic touch checks do not establish physical-device behavior.
Portfolio adoption, complete-lock review, scripts-disabled installation,
two-workspace real visible/clickable E acceptance and deployment remain separate.
No publishing, dependency downloads, Git writes or cross-chat messages are
authorized or performed by this continuation.
