# Development Phases

## Original Icon Library

- [x] Define the rounded-outline family and review the 20-icon pilot in kit controls.
- [x] Deliver 158 original icons with React, raw SVG, generation, and documentation.
- [x] Migrate UI/chart source, templates, stories, and current documentation.
- [x] Verify package builds, 260 tests, Storybook, React 18/19, Next.js, and browser accessibility.
- [x] Prepare local archive integrity evidence; publication and portfolio adoption remain separate.

## Phase 1: Foundation Components
**Goal:** Complete the base component primitives

- [x] Button system (complete)
- [x] Checkbox (complete)
- [x] Switch (complete)
- [x] Select (complete)
- [x] Badge (complete)
- [x] Avatar (complete)
- [x] Accordion (complete)
- [x] Spinner (complete)
- [x] Textarea (complete)
- [x] Input (complete)
- [x] Radio (complete)
- [ ] Typography (not implemented)

## Phase 2: Layout & Utility Components
**Goal:** Complete layout helpers and utility components

- [x] Card (complete)
- [x] Container (complete)
- [x] Flex (complete)
- [x] Grid (complete)
- [x] Dialog / Modal (complete)
- [x] Popover (complete)
- [x] Tooltip (complete)
- [x] Dropdown Menu (complete)
- [x] Tabs (complete)
- [x] Sheet / Drawer (complete)
- [x] Separator (complete)
- [x] Skeleton (complete)
- [x] Context Menu (complete)
- [x] Table (complete)

## Phase 3: Extended Component Set
**Goal:** Complete additional broadly reusable components

- [x] Navigation (Navbar, Navrail, Navdrawer) (complete)
- [x] Pagination (complete)
- [x] Progress Indicators (complete)
- [x] Stepper (basic) (complete)
- [x] Toast / Notification (basic) (complete)
- [x] Slider (basic) (complete)
- [x] Breadcrumb (complete)
- [x] InputIncrementor (complete)
- [x] Chip (complete)

## Phase 4: Advanced Interaction Components
**Goal:** High-value advanced components

- [x] FAB system (complete)
- [x] ComboBox/Autocomplete (complete)
- [x] Slider (advanced: range/step/icon variants) (complete)
- [x] Sheet (swipe-to-dismiss, snap points, spring animations) (complete)
- [x] Stepper (complex/non-linear variants) (complete)
- [x] Navigation Submenus (complete)
- [x] Toast (enhanced) (complete)

## Phase 5: Date & Time Components
**Goal:** Complete date and time selection components

- [x] Date Picker (complete)
- [x] Time Picker (complete)
- [x] DateTimePicker (complete)

## Phase 6: Data-Rich Components
**Goal:** Advanced complex components

- [x] Carousel (complete)
- [x] Multi-Select (complete)
- [x] Data Table (complete)
- [x] Command Palette (complete — moved up, blocker for investment-ops dashboard)
- [x] Toggle Group (complete — blocker for investment-ops dashboard)
- [x] Toolbar (complete — blocker for investment-ops dashboard)
- [x] Resizable (complete — blocker for investment-ops dashboard)

## Phase 7: Investment-Ops Finance Widgets
**Goal:** Finance-specific streaming widgets for the dashboard right rail

- [x] OrderBook (complete — exports from `./finance`)
- [x] TimeAndSales (complete — exports from `./finance`)

## Phase 8: Investment-Ops Templates
**Goal:** Composed presentational + interaction-focused blocks under `src/templates/investment-ops/`

- [x] StatTile
- [x] AccountSummary
- [x] Watchlist
- [x] HoldingsTable
- [x] OrderTicket (simple equity flow; multi-leg options deferred)
- [x] AllocationBreakdown
- [x] NewsFeed
- [x] InvestmentOpsDashboard (composed shell; integration showcase)
- [x] Secondary entrypoints (`./finance`, `./templates/investment-ops`) wired in `tsup.config.ts` + `package.json` `exports`
