# CalendarDaysIcon

Calendar Days — Actions.

Import CalendarDaysIcon from aapaetsch-icons or aapaetsch-icons/calendar-days.

Accepts IconProps, an SVG ref, size (default 1.5rem), strokeWidth (default 2), className, and standard SVG attributes. Decorative by default; name meaningful standalone images with aria-label or aria-labelledby. Name icon-only buttons on the button.

Artwork: svg/calendar-days.svg. Original AgentixUI geometry authored for this library; not traced or copied from another icon set.

Generated documentation; edit catalog.json or the generator. See the package DESIGN.md for geometry and semantics.
