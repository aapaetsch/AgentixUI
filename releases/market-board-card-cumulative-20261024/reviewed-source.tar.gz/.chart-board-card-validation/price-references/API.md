# Runtime supplied price references

Proposed cumulative successor: aapaetsch-charts-market@0.1.0-beta.3-board-card.4. Publication and consumer adoption are separate decisions.

`TechnicalChartView` and `MarketChart` accept `priceReferences?: readonly MarketPriceReference[]`. The core type is exported from the package and core entrypoints:

```tsx
import type {MarketPriceReference} from 'aapaetsch-charts-market';
const priceReferences: readonly MarketPriceReference[] = exactRegularOpen == null ? [] : [{
  id: 'regular-session-open',
  price: exactRegularOpen,
  label: 'Regular 09:30 ET open · supplied source/session',
  lineStyle: 'dotted',
  color: 'hsl(var(--muted-foreground))',
  showAxisLabel: true,
}];
<TechnicalChartView {...existingProps} priceReferences={priceReferences} />;
```

The consumer must select the exact already-supplied regular09:30ET open, own source/session copy and clear the array when evidence is absent or changes. Pass reference evidence atomically from the admitted data snapshot; the runtime input has no source/revision fields and cannot automatically validate its financial freshness. The renderer never chooses a session/bar, fetches data, computes an open or substitutes nearest/premarket/previous-session evidence. Explicit supplied references apply to the current rendered surface; they have no inferred time interval.

References are display-only runtime inputs. They are absent by default and excluded from saved chart state, calculation requests/identities, financial callbacks, drawing documents, selection, history and hit testing. The engine's optional `setPriceReferences` updates the current surface without engine reconstruction; alternate engines may omit the optional method. References do not expand the automatic price domain. Invalid/nonfinite prices, empty IDs/labels, duplicate IDs after the first valid entry, nonpositive log values and levels outside the current price domain are omitted. A chart with no supplied observations shows no references. No missing value is manufactured.

Lines use the existing price-pane geometry, clipping, transforms, CSS-pixel/DPR frame and theme. Dotted is the default and supported line style. The plot label names the supplied reference; optional outlined axis values have an R prefix and share collision placement with existing data badges. Last price and crosshair keep their existing priority; an overcrowded reference axis badge can be omitted while its named plot line remains. Long display labels are shortened to the available plot width; full label and exact price remain in a noninteractive accessible description. No pointer or keyboard target is introduced. Removal/revision clears on the next shared render; unmount destroys the existing engine surface.

The cumulative package also retains the zero-height empty-header fix and all Board2 controls/hover/geometry behavior. Existing external-title `paneMenuTrigger="none"` standard compact usage automatically receives the empty-header correction. Internal triggers, workspace handles and real study/volume/profile/VWAP legends keep their measured reservation. Product card height and price tick density remain consumer-controlled through existing APIs.

The final cumulative package also labels the already-supported bar-volume value `Vol` instead of `Count`, through the existing shared legend mapping. No consumer API or configuration is needed; Bar volume group copy, supplied values, formatting/null handling, direction colors and all economic/saved/calculation identities remain unchanged.

This local task authorizes no publication, dependencies/downloads, Git mutation, consumer/OpenBB/provider/database writes or cross-chat messages. Exact candidate evidence, independent review, publication and complete-lock/scripts-disabled consumer adoption remain separate.
