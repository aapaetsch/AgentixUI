# Compact instrument and OHLC candidate

The opt-in `TechnicalChartView.instrumentReadout` combines supplied identity,
decorative logo, period, exchange/currency and OHLC inside the price pane. Volume
and named studies follow beneath. It replaces the separate OHLC/Legend chrome in
this mode and preserves default/Board consumers. Missing, future and removed
inspected observations stay unavailable; explicit clear restores latest accepted
values. Original decimal evidence is bound to the committed source, identity and
accepted revision. No provider, logo discovery or financial formula was added.

The owner's DISPLAY-REVISION.md requests compact visible values. Ordinary OHLC
and averages show two decimals, volume is concise, ordinary OHLC stays in one tight row
and the four averages use one desktop line or two narrow lines. Original precision
remains available through accessible names, tooltips, keyboard and source evidence.

The public mapping, bounds and admission rules are in `PUBLIC-API.md` and the
packaged `charts-market/BOARD-INLINE-READOUT.md`. The host supplies existing listing
metadata and immutable original observations, removes redundant host identity
text, and retains its Objects/maximize/selection actions plus the existing public
pane-menu APIs. A logo and producer-supplied change/reference-basis evidence remain
separate optional inputs. Do not calculate change or infer a logo from the symbol.

Wrapped readouts set runtime pane minima without editing saved pane weights or
authored minima. A real plot body remains below each header. Existing geometry
feedback preserves the host height request and reports actual height/overflow;
the host retains scrolling when a small tile cannot fit the pane stack.

Validation receipts are in `dev-runner/results.json`, `dev-runner/review.json`
and `browser-results.json`; raw DOM/public-fixture observations and screenshots
are alongside them. The test matrix covers original precision, zero/null,
revision rejection, abandoned renders, exact pointer/keyboard inspection,
missing/future observations, status/evidence, metadata isolation, pane geometry,
logo recovery, long-name focus, themes and default/Board regressions. Required
desktop, four-tile, 390px and 320px browser layouts are reviewed with synthetic
supplied observations. Browser viewport emulation is not physical-device or
assistive-technology acceptance.

Known qualifications are retained rather than hidden: the broader legacy market
story type graph has 17 pre-existing diagnostics in four files; maintained/package/
public types pass. Scoped lint has no errors and retains two disclosed warnings.
SSR checks prove safe construction, not hydration. Earlier compiled real-engine
JSDOM keyboard attempts stalled and are excluded from accepted evidence; compiled
custom-engine callback consumers, real-engine source tests and actual browser
gestures are recorded separately. Full-suite Tooltip `act(...)` warnings are test
harness output, not a claim about browser warnings. See the exact final receipts
for counts, source/build bindings and accepted checks.

`candidate-pointer.json` identifies the immutable local package and source archive.
Its `receipt.json`, independent `candidate-review.json`, root `candidate-seal.json`
and `seal-verification.json` bind the exact bytes. Read-only attributes and a hash
inventory provide tamper detection, not OS-enforced immutability. The workspace
version, package manifests, dependencies and lockfiles are unchanged. This is a
local review candidate; publication, release-version assignment and exact product
dependency/lock/install/build adoption remain separate approvals under the
existing contract. No publication, Git write, outgoing chat message, consumer edit,
database/provider operation, install or download was performed for this request.

`preservation.json` verifies the exhaustive scope against the captured baseline,
including all prior candidates and protected workspace bytes. `TODO.md` tracks
completion. The optional local preview is served from the validated static build
at `http://127.0.0.1:6059/iframe.html?id=market-charts-instrument-readout--dark&viewMode=story`.
