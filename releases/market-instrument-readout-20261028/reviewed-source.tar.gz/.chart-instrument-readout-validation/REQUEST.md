# My Charts compact instrument and bar header

Prepared October 28, 2026 from the owner's TradingView label reference and
annotated My Charts screenshots. Owner authorized dispatch on October 28, 2026;
sent successfully to the existing UI-kit chart chat
`01a140c1-e3d6-7182-b4f8-735c6a258a5b`. No product runtime changes made.

## Visual direction

A quiet, compact header inside the price pane gives company identity first and
the inspected bar second, leaving the candles as the dominant visual.
Content order: supplied company logo, company name, interval, exchange, OHLC.
Existing study readouts follow beneath, with concise `vol` for supplied volume.
Inspection updates values in place; identity remains stable. Menu hover/focus
reveals existing actions without shifting the row. Respect reduced motion;
numeric inspection updates do not animate or flash.

Example structure (bracketed fields are placeholders, not market evidence):

    [logo] [Company name] · 1D · [Exchange]    O […] H […] L […] C […]
    vol […]    [visible study name, matching swatch and supplied value] …

The owner explicitly wants no visible `Legend`, `Bar volume`, `Rising bar` or
`Falling bar` text in this My Charts presentation. Remove those controls/keys and
their reserved space. Retain meaningful study names, parameters, matching swatches
and exact-observation values; this does not request removing indicator identity.
Avoid duplicate ticker/interval/exchange and OHLC rows. Keep chart selection,
Objects, maximize and existing pane actions reachable through public host APIs.

## Inspected consumer and public API evidence

- `frontend/components/my-charts-workspace.tsx` currently renders a host tile
  header with ticker, interval, exchange and currency plus Objects/maximize.
- `frontend/components/first-party-market-chart.tsx` composes supplied-mode
  `TechnicalChartView` with compact legends and no shared top-level header.
  Board opt-ins already use `appearance.studyReadout`.
- The installed public `TechnicalChartAppearance.studyReadout: 'inline'` removes
  the Legend disclosure and direction keys, retaining numeric study and volume
  readouts. `BOARD-INLINE-READOUT.md` documents this capability. It does not offer
  a combined company/logo/interval/exchange/OHLC header API. Preserve existing
  Board behavior and default consumers.
- `frontend/lib/api.ts` `ProductListing` supplies name, symbol, exchange, MIC,
  currency and exact listing identity. It supplies no logo URL. Do not infer a
  logo from ticker/domain or fetch one from a new provider/CDN.
- `frontend/lib/chart-presentation.ts` `RenderBar` supplies original decimal
  OHLC and optional volume, time and incomplete status. It contains no supplied
  previous-close change or percentage change. `market-chart-adapter.ts` converts
  values for plotting; original decimal strings remain the evidence.

## Shared public API request

Provide an additive, documented opt-in for a unified price-pane identity/readout
row, including host-supplied bounded company name, symbol, interval display,
exchange/currency and optional approved logo source. Exact API naming belongs to
the renderer. Host presentation metadata must not affect financial identities,
calculation requests, pane IDs, saved study definitions or result matching.

The renderer owns readout layout, crosshair synchronization, keyboard inspection,
pane-menu integration, height measurement, wrapping and theme behavior. The host
owns authorized listing metadata and existing symbol-selection/Objects/maximize
actions. Provide documented slots/callbacks if needed; no product-side duplicate
crosshair implementation, copied renderer, private DOM selectors or CSS hiding.

Use the latest accepted bar when idle and the exact inspected bar on inspection.
Do not silently choose a nearby/latest bar for gaps or missing observations.
Restore the latest accepted values when inspection ends. Label OHLC explicitly;
preserve display precision and expose the original supplied decimals accessibly.
Null stays unavailable and zero stays zero. Retain incomplete-bar, stale, partial,
warning and rejected-update semantics. Do not announce every pointer move through
an ARIA live region. Keyboard inspection must expose equivalent information.

Use a supplied logo only when available through an approved host asset path.
Missing/broken logos collapse cleanly or use a neutral ticker monogram, never a
fabricated company mark. The company's textual identity remains accessible.
Logos are decorative beside that text; bound image dimensions and avoid layout
shift. Long company names may ellipsize with the complete name available on
focus/hover and to assistive technology. Missing names fall back to the symbol;
never infer listing identity, exchange or period from company text.

The reference's absolute/percentage change must be omitted until explicit
producer-supplied values and reference-basis semantics are available. Do not
compute financial changes or percentages in the renderer or product/browser.
This request authorizes no new producer work or source access.

## Responsiveness, themes and stories

Desktop should read as one compact identity/OHLC row wherever space permits.
Narrow/multi-chart layouts may wrap identity and atomic label/value pairs into
two or more measured rows without clipping, horizontal scrolling, collision
with pane controls or extra blank header bands. Preserve existing minimum plot
sizes and host scrolling. Support dark, light and custom themes with readable
contrast and tabular numeric alignment. Do not rely on red/green alone.

Add synthetic supplied stories for a long company name, supplied/missing/broken
logo, same symbol on different exchanges, 1D/1W/1M/intraday intervals, no bars,
zero volume, null/missing observations, high-precision decimals, incomplete bars,
stale/partial/rejected evidence, multiple overlays and oscillator panes. Include
the existing default and Board inline/volume-only surfaces as regressions.

## Acceptance and review

- No visible/focusable Legend disclosure or bar-direction color key in the opt-in.
- Identity and OHLC appear in the requested order without duplicate header rows.
- Hover/keyboard inspection selects one exact accepted observation across OHLC,
  volume and visible studies; clearing inspection restores latest values.
- Existing source-free pan/zoom, drawings, earnings, pane menus, status and
  immutable result identities remain intact. No financial formula is added.
- Verify 1440px desktop, four-chart tiles, 390px and 320px widths, light/dark,
  pointer/keyboard, long labels and stable idle/resizing geometry. Supply browser
  screenshots and relevant tests/stories with the documented public API mapping.
- Return a sealed immutable candidate for independent review using existing
  dependencies. Publication and exact version/lock/install/build adoption remain
  separate approvals under the existing dependency contract.

## Proposed receiving scope and product follow-up

Existing receiving project: `C:/Users/aapae/Documents/Projects/Aidans-React-UI`.
Proposed exhaustive write allowlist: `charts-market/`, `docs/ROADMAP.md`, and
`.chart-instrument-readout-validation/`. Record baseline HEAD/status and preserve
unrelated work and all prior immutable candidates. Everything else is read-only.
Scope covers source preparation and existing-dependency tests/build/browser review
only. No downloads, publication, commits/pushes/PRs, cross-chat messages, database
operations, provider access or edits to this product/OpenBB repository.

After reviewed public API delivery and required dependency approvals, this product
can pass existing listing name/exchange, remove redundant host identity text,
enable the new My Charts presentation, and retain its private selection and pane
actions. Logo acquisition and supplied price-change evidence are separate missing
inputs, not prerequisites for a graceful header. Validate the rebuilt product at
[My Charts](http://localhost:3000/my-charts) at desktop and narrow widths with
retained owner-authorized evidence and no new source acquisition.

Dispatch was owner-authorized and confirmed by the chat messaging tool. This
authorizes the scoped preparation above, not publication or dependency adoption.
