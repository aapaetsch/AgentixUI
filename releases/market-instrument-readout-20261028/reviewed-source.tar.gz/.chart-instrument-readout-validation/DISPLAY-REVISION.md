# Owner display revision

The owner directly requested during review:

> why are the o/h/l/c not in line? why cant we also have the 20 ema, 50 ma, 150 ma, 200 ma also either share 1 line or 2 lines? it seems like we are using way way way too many decimal places for things?

This steers the existing local candidate work: use compact visible formatting,
keep OHLC together on one line, and show the four averages in one desktop line or
two narrow lines. Ordinary prices/studies display two decimal places. Tiny values
keep useful significant digits/scientific notation; volume uses concise K/M
notation. Original accepted decimals stay unchanged in accessible names, titles,
keyboard inspection and producer evidence. No financial value, formula, request,
saved state, revision or source identity changes.

The owner then clarified that OHLC should sit closer together and adjust if
values are larger. OHLC therefore uses intrinsic-width atomic pairs with a6px
gap, without equal-width columns or smaller fonts. Larger values expand their
pair naturally and wrap only when necessary. Named averages use
two columns, with vol on its own row. Pane controls reserve space only beside
identity, preserving the numeric rows' width. Desktop retains natural inline
composition. Existing defaults and Board modes do not opt into this formatting.
All original scope/publication/dependency restrictions remain in effect.
