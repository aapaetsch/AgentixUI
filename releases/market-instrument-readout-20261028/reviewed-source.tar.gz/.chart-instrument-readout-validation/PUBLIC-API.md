# Proposed additive instrument readout

`TechnicalChartView.instrumentReadout?: TechnicalChartInstrumentReadout` enables
the measured combined price-pane row. Identity fields are runtime presentation
only: name (256 code points), symbol (40), period (24), exchange (80), currency
(16), optional logo `{src}` and optional `onSelect` callback. Missing/invalid names
fall back to the bounded explicit symbol or existing symbol prop. Name focus/hover
and accessible text expose the complete accepted name. Logo is decorative, fixed
size; missing/broken/unapproved source collapses without fetching fallback assets.

`instrumentReadout.exactValues?: {identity:string;revision?:number;source: readonly OhlcBar[];
observations: readonly TechnicalChartReadoutObservation[]}` supplies original
decimal evidence separately from plot values. `source` MUST be the same immutable
array passed to `data`. The renderer admits it only when it is the exact accepted
array and identity/revision match the admitted dataset. New evidence is admitted
only on accepted/unchanged revision receipts (or source-bound unversioned data);
even a rejected update reusing the same array cannot change exact text. Previously
admitted text can remain only while source, dataset identity and accepted revision
remain unchanged. The cache advances in layout commit, never an abandoned render.
Observations are keyed by exact accepted timestamp, with
open/high/low/close strings or null, optional volume and `studies` keyed by full
render-series IDs. Plain finite decimals are bounded to128characters and must
project to the admitted numeric value. Null is unavailable; missing/mismatched
OHLC/volume entries in a supplied evidence set remain unavailable rather than silently using
rounded/stale values. Optional studies are independent: omitted study metadata
retains admitted numeric result values; supplied study text cannot revive missing
or unmatched numeric series. Without exactValues, existing numeric values are shown with
their complete numeric string in accessibility/title.

The opt-in defaults shared header/commands off (explicit features overrides remain
available), supersedes the separate OHLC row, and forces
the existing inline numeric study projection on all panes. Company, period,
exchange/currency precede OHLC; `vol` and named studies follow beneath. Host
identity outside the component must be removed by the product at adoption.
Existing `paneMenu`, `paneMenuTrigger`, `useTechnicalPaneMenu` and host-owned
actions remain the public composition path. No change/percentage is generated.

New engine snapshot `inspectionUnavailable?: boolean` distinguishes an active
missing/gap observation from idle; the combined mode clears OHLC/volume/studies
there and for future inspection. Existing exact crosshair/keyboard pathways own
selection. `MarketChart.formatKeyboardInspection` allows the composite to supply
the exact combined description to the existing keyboard-only announcement, never
pointer-move live output. Presentation `ohlcInPaneHeader?: boolean` removes only
the obsolete separate OHLC allocation from price-scale/axis-note geometry.

No metadata enters saved state, requests, economic identity, admission or formulas.
Default consumers and Boards without instrumentReadout retain existing behavior.
No dependency/version/lock edits or publication are authorized.

The renderer derives runtime pane minima from each measured header plus the
existing price28/other10px bottom allowance and48px plot body. Larger authored
minima are respected. Collapsed panes stay28px; hidden/maximized panes use their
actual visible layout. Summed minima include the28px time axis. Existing geometry
feedback reports overflow/actual plot height while preserving the host request;
the host retains scrolling. Saved pane weights/minima and economic inputs remain
unchanged. Default consumers retain their previous height semantics.

Owner display revision: see DISPLAY-REVISION.md. Ordinary visible OHLC/studies
use two decimals, tiny values use useful significant digits/scientific notation,
and volume is compact. Raw original aria/title/keyboard/evidence values remain
unchanged. OHLC uses tightly spaced intrinsic-width pairs, wrapping only when
larger values require it. Narrow price panes use a two-column
average grid (vol on its own row); controls reserve only identity-row space.
Existing defaults/Board modes keep their previous formatting.
