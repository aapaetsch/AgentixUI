import type { MarketChartType, OhlcBar } from "../core";
import {adaptiveBarGeometry} from './bar-geometry';
import type {
  MarketSeriesRendererContext,
  MarketSeriesRendererDefinition,
} from "../core/engine";
export type {
  MarketSeriesRendererContext,
  MarketSeriesRendererDefinition,
} from "../core/engine";
function drawSeries(
  type: MarketChartType,
  {
    context,
    scale,
    pane,
    visible,
    startIndex,
    barSpacing,
    pixelRatio,
    logicalToCoordinate,
    timeToCoordinate,
    isTimeSegmentContinuous,
    theme,
    presentation,
  }: MarketSeriesRendererContext,
): void {
  if (!visible.length) return;
  const spacing = barSpacing;
  const adaptive = presentation?.candles?.widthMode === 'adaptive';
  const bodyWidth = Math.max(1, Math.floor(Math.min(presentation?.candles?.maximumWidth ?? 14, spacing * (presentation?.candles?.bodyRatio ?? 0.7))));
  if (["line", "area", "baseline"].includes(type)) {
    const points = visible
      .map((bar, offset) => ({
        x: timeToCoordinate ? timeToCoordinate(bar.time) : logicalToCoordinate(startIndex + offset),
        y: scale.toCoordinate(bar.close),
        bar,
      }));
    if (!points.length) return;
    context.strokeStyle = theme.primary;
    context.fillStyle = theme.primary;
    const lineWidth = presentation?.line?.width ?? 2;
    context.lineWidth = lineWidth;
    const segments: {x:number;y:number;bar:OhlcBar}[][] = [];
    let broken=true;
    points.forEach(point => {
      if(point.x==null||point.y==null||!Number.isFinite(point.x)||!Number.isFinite(point.y)||isTimeSegmentContinuous?.(point.bar.time,point.bar.time)===false){broken=true;return;}
      const valid={x:point.x,y:point.y,bar:point.bar};
      const segment = segments.at(-1), previous = segment?.at(-1);
      if (broken || !previous || isTimeSegmentContinuous?.(previous.bar.time, point.bar.time) === false) segments.push([valid]);
      else segment!.push(valid);
      broken=false;
    });
    segments.forEach(segment => {
      if (segment.length === 1) { const point = segment[0]; context.fillRect(point.x - lineWidth, point.y - lineWidth, lineWidth * 2, lineWidth * 2); return; }
      context.beginPath();
      segment.forEach((point,index) => index ? context.lineTo(point.x,point.y) : context.moveTo(point.x,point.y));
      context.stroke();
      if (type === "area") {
        context.lineTo(segment.at(-1)!.x, pane.top + pane.height);
        context.lineTo(segment[0].x, pane.top + pane.height);
        context.closePath(); context.globalAlpha = 0.14; context.fill(); context.globalAlpha = 1;
      }
    });
    if (type === "baseline") {
      const baseline = scale.toCoordinate(visible[0].close);
      if (baseline != null) {
        context.strokeStyle = theme.border;
        context.lineWidth = 2;
        context.setLineDash([4, 4]);
        context.beginPath();
        context.moveTo(0, baseline);
        context.lineTo((pane.left ?? 0) + pane.width, baseline);
        context.stroke();
        context.setLineDash([]);
      }
    }
    return;
  }
  visible.forEach((bar, offset) => {
    const x = adaptive && timeToCoordinate ? timeToCoordinate(bar.time) : logicalToCoordinate(startIndex + offset);
    if (x == null || !Number.isFinite(x) || isTimeSegmentContinuous?.(bar.time, bar.time) === false) return;
    const geometry = adaptive ? adaptiveBarGeometry(x, spacing, presentation?.candles?.gap, pixelRatio) : {left: x - bodyWidth / 2, width: bodyWidth, center: x};
    if (!geometry) return;
    const open = scale.toCoordinate(bar.open);
    const high = scale.toCoordinate(bar.high);
    const low = scale.toCoordinate(bar.low);
    const close = scale.toCoordinate(bar.close);
    if ([open, high, low, close].some((value) => value == null)) return;
    const color = bar.close >= bar.open ? theme.positive : theme.negative;
    context.setLineDash(bar.incomplete ? [3, 3] : []);
    context.strokeStyle = color;
    context.fillStyle = color;
    const strokeWidth = adaptive ? Math.min(presentation?.candles?.wickWidth ?? 1, geometry.width) : presentation?.candles?.wickWidth ?? 1;
    context.lineWidth = strokeWidth;
    const stemX = adaptive ? geometry.center : Math.round(x) + 0.5;
    context.beginPath();
    context.moveTo(stemX, high!);
    context.lineTo(stemX, low!);
    context.stroke();
    if (
      type === "candlestick" &&
      theme.positive === theme.negative &&
      bar.close >= bar.open || type === "candlestick" && bar.incomplete
    )
      {
        const height = Math.max(1, Math.abs(close! - open!));
        const inset = adaptive ? Math.min(strokeWidth, height) / 2 : 0;
        if (adaptive) context.lineWidth = inset * 2;
        if (adaptive && geometry.width <= inset * 2 && height <= inset * 2)
          context.fillRect(geometry.left, Math.min(open!, close!), geometry.width, height);
        else context.strokeRect(geometry.left + inset, Math.min(open!, close!) + inset, geometry.width - inset * 2, height - inset * 2);
      }
    else if (type === "candlestick")
      context.fillRect(
        geometry.left,
        Math.min(open!, close!),
        geometry.width,
        Math.max(1, Math.abs(close! - open!)),
      );
    else if (presentation?.bars?.tickWidth != null) {
      // Retain proportional stem snapping; adaptive ticks use the exact supplied center.
      // Butt caps need no horizontal inset, even when a slot is narrower than a device pixel.
      const left = stemX - geometry.width / 2, right = stemX + geometry.width / 2;
      context.save();
      context.lineWidth = presentation.bars.tickWidth;
      context.lineCap = 'butt';
      context.beginPath();
      context.moveTo(left, open!);
      context.lineTo(stemX, open!);
      context.moveTo(stemX, close!);
      context.lineTo(right, close!);
      context.stroke();
      context.restore();
    }
    else {
      context.beginPath();
      context.moveTo(geometry.left + (adaptive ? strokeWidth / 2 : 0), open!);
      context.lineTo(x, open!);
      context.moveTo(x, close!);
      context.lineTo(geometry.left + geometry.width - (adaptive ? strokeWidth / 2 : 0), close!);
      context.stroke();
    }
    context.setLineDash([]);
  });
}
/** Registry preserves the five existing renderers and permits replacement without modifying the engine. */
export const builtInSeriesRenderers: MarketSeriesRendererDefinition[] = (
  ["candlestick", "bar", "line", "area", "baseline"] as MarketChartType[]
).map((id) => ({ id, draw: (context) => drawSeries(id, context) }));
