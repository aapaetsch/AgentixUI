# Quiet compact Board status and daily-open reference

Owner-authorized correction dispatched from Portfolio's existing chat on October25,2026.

Add host-owned supplied-status presentation with no summary/warning/button/focus/header allocation. Preserve admission, matching, request identities, calculations, accepted/rejected results, and distinct loading/error/stale semantics. The host already exposes complete numeric values and exact warnings/evidence through its expanded surface.

Add axis-only supplied price references: subtle dotted line, short Open caption and price in the existing axis lane, no plot caption, complete source/session/date/currency/exact value in accessibility and hover/focus explanation. Omitted options preserve default plot labels/R badges. Display-only references never expand autoscale, create source observations, become drawings or financial intents.

No new per-card Legend/Details/info button, disclosure, footer or row. Existing title menu/expand remain. Actual plot reclaims chrome within310pxdesktop/330pxnarrow. Preserve volume-only, selected-average lines/badges, OHLC, volume, earnings, crosshair/line dot and expanded readouts.

Validate none/one/four averages and complete/partial/warmup/null/unavailable/stale/rejected evidence; no bars; volume on/off/missing; compact/expanded/defaults; dense desktop;320/390/430px light/dark; keyboard/accessibility/pointer, label collision/large+decimal/offscale/session/pan/zoom; no phantom gap/focus; stable resize and idle. Return typed public mapping, tests/stories/screenshots/independent review/local immutable candidate.

Write allowlist: charts-market/, docs/ROADMAP.md, .chart-board-card-validation/. Preserve unrelated work/prior candidates. Existing dependencies only. No downloads/new dependencies/publication/version approval/consumer adoption/commits/pushes/PRs/service or DB operations/source acquisition/outgoing messages authorized.
