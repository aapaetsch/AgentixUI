# Public mapping for quiet compact Boards

Numeric axis-only labels fit large prices and requested fonts by reducing display precision/scientific notation first, then fitting only the numeric font if the shortest whole sign/exponent/unit still exceeds the lane. No sign or exponent is clipped; exact prices remain in the existing accessibility/hover evidence. Default R badges keep their existing formatter.

```tsx
const compactBoard = isBoard && compact;
const appearance: TechnicalChartAppearance = {
  ...existingAppearance,
  studyReadout: isBoard ? compactBoard ? 'volume-only' : 'inline' : undefined,
  suppliedStatus: compactBoard ? 'host' : existingAppearance.suppliedStatus,
  suppliedDetails: compactBoard ? false : existingAppearance.suppliedDetails,
};
const references: MarketPriceReference[] = exactSuppliedOpen == null ? [] : [{
  id: suppliedSessionId,
  price: exactSuppliedOpen,
  label: completeHostOwnedSessionDateTimeSourceCurrencyAndExactValue,
  lineStyle: 'dotted',
  showAxisLabel: true,
  showPlotLabel: compactBoard ? false : undefined,
  axisLabel: compactBoard ? 'Open' : undefined,
}];
```

`suppliedStatus:'host'` transfers the study status/evidence presentation to the host's existing discoverable expanded surface. It allocates no status row, warning block, details button, profile-summary footer, internal dialog or focus stop, including when `suppliedDetails` is omitted. It does not classify evidence as complete, admit rejected updates, change missing identity behavior, hide the MarketChart `loading` or `error` surface, or change supplied results. Retain full warnings, source descriptions, stale/error/loading/rejected states and exact selected numeric values in host evidence; wire genuine refresh/failure state through existing host/data and chart props, independently of study coverage. Do not use it without that replacement surface. Default expanded/compact behavior and My Charts remain unchanged.

`showPlotLabel:false` suppresses only the reference's in-plot caption. `showAxisLabel:true, axisLabel:'Open'` uses two small lines in the current72/88px axis lane. The caption replaces the default R prefix. Numeric normal/log prices use the existing whole-number/scientific display formatter to preserve signs/exponents within the lane; percentage/indexed axes retain their existing transformed units. Exact host price and full label remain in the screen-reader reference description and existing focusable chart's accessible description. Hovering the rendered axis badge exposes the full native title. No new focus stop/button is introduced. Missing, offscale or nonpositive log references never acquire a replacement value; offscale references remain accessible without a clamped plot line/badge. Empty full labels still reject the reference.

Canvas badge placement accounts for tick/crosshair obstacles and the engine-owned moving-average box geometry. With insufficient lane height, the existing priority layout omits a lower-priority reference badge rather than covering a higher-priority price or selected-average box; its full evidence stays accessible. No lane/card/domain widening is introduced. Product keeps310pxdesktop/330pxnarrow allocation and supplies its actual measured chart slot.

This is source/candidate preparation only. No release version, publication or consumer dependency/complete-lock/scripts-disabled-install approval is inferred.
