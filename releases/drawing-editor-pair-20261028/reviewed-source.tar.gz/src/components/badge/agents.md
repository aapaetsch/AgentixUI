# Badge Components
## Important Notes
- Follow **shadcn/ui** design patterns and conventions closely, call the mcp server for component examples when adding new components and see how they are implemented in shadcn/ui.
- You should always create a **TODO LIST** by calling the todo list tool whenever you are given a new task to work on. You should update the TODO LIST as you make progress on the task. You will never forget to create or update the TODO LIST and you will not stop until the task and the TODO LIST is complete.
- After you complete a task involving code changes, you must call the `Dev Runner` subagent using the `agent/runSubagent` tool to run the build and Storybook to verify that everything works correctly. If there are any build or Storybook errors, you must fix them before marking the task as complete.
- As components are implemented, you must update their status in the `docs/ROADMAP.md` file to reflect current progress.
- **Inspiration:** Draw from **Google Material Design** and **Tailwind Catalyst** components for guidance on structure, spacing, and visual hierarchy.

A comprehensive badge system following Material Design 3 patterns with shadcn/ui styling foundation.

## Components

### Badge
Standard badge with multiple variants and sizes, supporting text and numeric content.

### BadgeAnchor
Wrapper component for positioning badges on other elements (icons, navigation items).

### AnimatedBadge
Badge with built-in entrance/exit animations following MD3 motion guidelines.

## Props

### Badge Props
```typescript
interface BadgeProps {
  variant?: 'default' | 'secondary' | 'destructive' | 'outline' | 'success' | 'warning';
  size?: 'small' | 'medium' | 'large';  // small=dot, medium=20px, large=24px
  asChild?: boolean;           // Render as child element
  tabularNums?: boolean;       // Force tabular numerals (auto-enabled for numbers)
  maxChars?: number;           // Max characters before truncation (default: 4)
}
```

### BadgeAnchor Props
```typescript
interface BadgeAnchorProps {
  badge: React.ReactElement<BadgeProps>;  // The badge to position
  position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left';
  showBadge?: boolean;         // Control badge visibility (default: true)
  animate?: boolean;           // Enable entrance/exit animations (default: true)
}
```

### AnimatedBadge Props
```typescript
interface AnimatedBadgeProps extends BadgeProps {
  visible?: boolean;           // Control visibility (default: true)
  animation?: 'scale' | 'fade' | 'slide';  // Animation type (default: 'scale')
}
```

## Dependencies
- `@radix-ui/react-slot` - Polymorphic component (asChild prop)
- `class-variance-authority` - Variant management
- `../../lib/utils` - `cn()` utility

## Styling Decisions

### Variants
| Variant | Container | Text | Use Case |
|---------|-----------|------|----------|
| `default` | Primary | Primary Foreground | Standard notifications |
| `secondary` | Secondary | Secondary Foreground | Low-emphasis |
| `destructive` | Destructive | White | Errors, critical counts |
| `outline` | Transparent + border | Foreground | Subtle indicators |
| `success` | Green | White | Success states |
| `warning` | Amber | Black | Warning states |

### Sizes (MD3 Badge Types)
| Size | Type | Dimensions | Use Case |
|------|------|------------|----------|
| `small` | Dot | 8x8px | Unread indicator, no text |
| `medium` | Standard | h-20px, min-w-20px | Default badge with text |
| `large` | Emphasis | h-24px, min-w-24px | Larger text badges |

### MD3 Features Implemented

1. **Two Badge Types**
   - Small: Simple dot indicator (no text content)
   - Large: Container with label text (medium/large sizes)

2. **Character Limiting**
   - Maximum 4 characters by default (configurable)
   - Numbers over 999 display as "999+"
   - Prevents badge overflow and collision

3. **Tabular Numerals**
   - Automatically enabled for numeric content
   - Uses `font-variant-numeric: tabular-nums`
   - Ensures consistent width for changing numbers

4. **RTL Support**
   - BadgeAnchor positions automatically mirror for RTL layouts
   - Uses Tailwind's `rtl:` modifier for positioning

5. **Placement Guidelines**
   - Top-right default (standard for notifications)
   - Small badges positioned closer to anchor element
   - Large badges offset slightly for visibility

6. **Motion/Animation**
   - Scale animation (default): Grows/shrinks from center
   - Fade animation: Opacity transition
   - Slide animation: Slides up/down with fade
   - Duration: 200ms (--motion-duration-medium)
   - Easing: cubic-bezier(0.2, 0, 0, 1) (--motion-easing-standard)

### CSS Variables Used
```css
--motion-duration-medium
--motion-easing-standard
--primary, --primary-foreground
--secondary, --secondary-foreground
--destructive
--foreground
--ring
```

## Maintenance Notes

### Accessibility
- Badge content is read by screen readers
- Small badges (dots) should have parent element with appropriate aria-label
- Color contrast meets WCAG 2.1 AA standards (3:1 minimum)
- Focus states with visible ring for interactive badges (asChild as link)

### Numeric Content
- Pass numbers directly: `<Badge>{count}</Badge>`
- Automatic truncation: 1234 → "999+"
- Custom maxChars: `<Badge maxChars={2}>{100}</Badge>` → "9+"

### RTL Considerations
- Position names remain logical (top-right = trailing edge)
- Actual positioning flips automatically via `rtl:` classes
- Test with `dir="rtl"` on parent element

### Edge Cases
- Empty badge renders as empty span (use small size for dot)
- Zero values still render (use showBadge={false} to hide)
- Very long text will overflow (use maxChars or truncate content)
- AnimatedBadge with visible={false} remains in DOM (pointer-events-none)

### Integration with Navigation
```tsx
// Hide badge when destination selected (MD3 guideline)
<BadgeAnchor 
  badge={<Badge>{count}</Badge>} 
  showBadge={!isSelected && count > 0}
>
  <NavIcon />
</BadgeAnchor>
```


