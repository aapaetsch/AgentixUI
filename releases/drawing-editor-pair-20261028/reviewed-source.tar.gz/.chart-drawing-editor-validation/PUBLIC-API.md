# Agreed editor contract for product integration

Fullscreen support also requires the paired amended UI-kit Content `portalContainer`
API. The current published UI peer lacks it. Local candidates retain unchanged
workspace versions/manifests; a coordinated publication/peer-minimum proposal and
exact consumer dependency/complete-lock/install approval remain separate gates.

Prepared October 28 before implementation. These names will be exported from the
package root and `/drawings`; the engine geometry additions also belong to `/core`.
This file is the early integration contract, not a claim that implementation or
publication is complete. No outgoing chat message is authorized.

```ts
type MarketDrawingStatistic = 'price_range' | 'percent_change' | 'change_in_pips'
  | 'bars_range' | 'date_time_range' | 'distance' | 'angle';
type MarketDrawingPresentation = {
  startCap?: 'normal' | 'arrow'; endCap?: 'normal' | 'arrow';
  middlePoint?: boolean; priceLabels?: boolean;
  text?: {value: string; color: string; fontSize: number; bold: boolean; italic: boolean;
    verticalAlignment: 'top' | 'middle' | 'bottom';
    horizontalAlignment: 'left' | 'center' | 'right'};
  statistics?: MarketDrawingStatistic[];
  statisticsPosition?: 'left' | 'center' | 'right' | 'auto';
  alwaysShowStatistics?: boolean;
  visibility?: Partial<Record<'minutes'|'hours'|'days'|'weeks'|'months',
    {enabled: boolean; min: number; max: number}>>;
};
type MarketDrawingEditorPosition = {x: number; y: number};
type MarketDrawingSuppliedStatistics = {
  drawingId: string; geometryKey: string;
  contextKey: string;
  values: Partial<Record<'price_range'|'percent_change'|'bars_range'|'date_time_range', string|null>>;
};
interface MarketDrawingEditorOptions {
  active: boolean;
  position?: MarketDrawingEditorPosition|null;
  onPositionChange?: (position: MarketDrawingEditorPosition|null) => void;
  timeZone?: string; // inherits chart timezone, then UTC; explicit offsets disambiguate DST folds
  statistics?: readonly MarketDrawingSuppliedStatistics[];
  statisticsContextKey?: string;
  onAlertIntent?: (drawingId: string) => void; // omitted => disabled coming-later bell
}
// Added to MarketChartProps and TechnicalChartViewProps:
// drawingEditor?: MarketDrawingEditorOptions
```

Persistence mapping: `name`, `visible`, `locked` use the existing top-level
DrawingState fields. `color`, `width`, `line_style`, `extend_left`, `extend_right`
map to `parameters.color`, `lineWidth`, `dashStyle`, `extendLeft`, `extendRight`.
The remaining private presentation keys map one-to-one to camelCase keys under
`parameters.presentation`. Statistic enum VALUES and interval-family keys remain
unchanged. Text font_size/vertical_alignment/horizontal_alignment become
fontSize/verticalAlignment/horizontalAlignment. Omitted keys stay omitted; selected
defaults never create documents or callbacks. Product keeps strict DTO validation.

Exact edits use additive public `DrawingPoint.priceText?: string` and
`DrawingPoint.utcTimeText?: string` (UTC ISO ending Z or +00:00, at most six
fractional digits, years 0001..9999), alongside existing
numeric price/time geometry. Seed these with the exact private anchor strings in
the adapter. They are authored annotation coordinates, not observations or computed
financial values. Only changed coordinates replace their text; other strings stay
byte-identical. History retains the text, so even decimals that collapse to the
same JavaScript number have distinct undo/redo transactions.

`DrawingChangeMetadata.exactCoordinates?: Array<{drawingId:string;pointIndex:number;
price?:string;utcTime?:string}>` reports retained exact text on final commits and
undo/redo. TechnicalChartView forwards this as
`TechnicalChartViewChangeMetadata.drawing?: DrawingChangeMetadata`. Product should
prefer a point's valid priceText/utcTimeText and/or the matching metadata entry;
otherwise retain its existing unchanged-anchor comparison and numeric-gesture
conversion. No numeric round-trip is performed merely by opening/closing settings.

`marketDrawingGeometryKey(drawing)` keys supplied statistics by type and exact
anchor geometry (including exact price and semantic UTC microsecond identity).
Z/+00:00 and equivalent trailing fractional zeros compare equal without changing
raw snapshots/metadata; distinct microseconds remain distinct. History/controlled
echo comparisons also ignore JSON object-key order while retaining array order.
Supplied contextKey must also match the active
statisticsContextKey; omit the context and financial values stay unavailable.
Hosts clear/reissue results atomically on admitted dataset/revision changes.
Only exact context and geometry matches are shown. Geometry
previews and unacknowledged edits suppress prior supplied values. Price range,
percent change, bars and date/time range are never calculated in the renderer.
Distance and angle are CSS-pixel geometry; pips remain unavailable.

`MarketChartEngine.logicalForTime?` / `timeForLogical?` expose the existing ruler
mapping. Coordinate editor indexes convert immediately to timestamps and are never
stored. `MarketChartSnapshot.timeAxis?` exposes actual axis bounds for endpoint
labels/span. No private DOM selectors or duplicate time scale.

The editor accepts canonical plain decimal prices (the product DTO's syntax,
up to 80 characters), not exponents/commas. Newly edited time/ruler inputs commit
unambiguous millisecond UTC timestamps. Unchanged original UTC strings, including
their finer fractional precision, remain byte-identical. Completed active opt-in
create/move/resize/duplicate/clipboard frames receive missing canonical price and
millisecond UTC text before history/callbacks. Valid existing strings stay intact;
selection, drafts, cancellation and opt-out never materialize fields. An affected
coordinate outside the 80-character finite Decimal/UTC contract rejects the whole
transaction with an accessibility announcement, no callback and no history entry.
A host's
explicit shared cancel command clears outstanding optimistic editor acknowledgements;
ordinary delayed/out-of-order echoes retain the latest shared transaction.

Only active editable instances opt in. Inactive opt-in instances suppress both the
new and legacy contextual editor. Missing drawingEditor retains historical behavior.
One selected visible supported object gets one toolbar; multi-selection retains
existing commands/history without this editor. Locked objects remain selectable
and unlockable while geometry/style/text editing is disabled. Hide uses existing
object-tree recovery. Position is runtime account-session state, outside drawing
documents/history. The fixed portal inherits the chart theme and clamps to the
visual viewport. Reset reports null; drag/keyboard movement reports viewport x/y.
