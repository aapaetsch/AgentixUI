# Floating drawing editor and selected timeline range

Owner-authorized implementation request, October 28, 2026. Continue existing
UI-kit chat `01a140c1-e3d6-7182-b4f8-735c6a258a5b`; do not create another chat.
Product: [My Charts](https://minecraft-server.tailec7cc2.ts.net:9443/my-charts)
and [loopback My Charts](http://localhost:3000/my-charts).

## Outcome and visual direction

The chart remains the dominant surface. Use a small themed floating icon toolbar,
subtle border/shadow, compact four-tab settings dialog and restrained selected
timeline labels, following the owner screenshots in this conversation. Interaction
uses fast focus/menu feedback, direct drag feedback and reduced-motion support.
No hero, decorative imagery, templates, provider acquisition or live alerts.

Current product evidence (read-only): `frontend/components/first-party-market-chart.tsx`
composes TechnicalChartView supplied mode with controlled state and shared drawing
history; `frontend/lib/market-chart-adapter.ts` owns Decimal-preserving conversion;
`frontend/lib/chart-settings.ts` and backend `charts/workspace.py` own validation;
`docs/architecture/chart-drawing-autosave.md` owns private persistence. Existing
shared drawing-layer.tsx has a fixed in-chart selection toolbar; expand that public
abstraction rather than copying it into product code. Preserve current future-axis,
line-extension, supplied-result, Board, gesture, pane and viewport behavior.

## Required shared behavior

- Opt-in editor for the active editable My Charts instance only; no change to
  Board/read-only/default consumers. One selected trend/horizontal/vertical line
  or rectangle gets one contextual toolbar. Multi-selection retains existing
  history/commands but suppresses this single-object editor.
- Page-wide fixed/portal toolbar, initially upper-center of its chart. Drag only
  its handle with pointer/touch capture; never pan chart. Clamp to visual viewport
  on scroll/resize/fullscreen/panel changes. Keyboard handle movement and Reset
  position action. Public controlled position permits account-session host memory;
  omit DOM inspection/private selectors. Narrow layouts overflow secondary actions.
- Color, text shortcut, width 1..5, solid/dashed/dotted style, Settings, explicitly
  disabled bell "Drawing alerts — coming later", lock/unlock, delete, overflow Hide
  and Reset position. Optional future drawing-ID alert intent, disabled in product.
- Locked items selectable/unlockable, but no geometry/style/text edits. Hidden items
  recoverable through object tree. Escape/cancel/blur/unmount release capture/drafts.
- Quick settings preview then one history commit. Dialog has Style/Text/Coordinates/
  Visibility tabs, bounded editable name, OK/Cancel. Entire draft is one commit;
  cancellation/selection change makes no persistence/history change.
- Style: current color/width/dash; normal/arrow ends for trends; independent left/
  right extensions for trend/horizontal; midpoint for paired shapes; price labels
  where prices are meaningful; paired-shape statistics selection, Left/Center/Right/
  Auto position and Always show stats. Preserve previous extension defaults.
- Text: plain text <=2000 characters, color, font size 8..48, bold/italic, Top/Middle/
  Bottom and Left/Center/Right alignment. No HTML execution.
- Coordinates: exact decimal string edit channel, time/date in chart timezone with
  unambiguous UTC storage, and current engine bar/ruler coordinates mapped immediately
  to durable timestamps. Do not persist indexes or round unrelated anchor strings.
  Product needs exact-coordinate commit metadata or equivalent public API, because
  DrawingState.points numeric renderer coordinates cannot preserve typed decimals.
- Visibility: enabled/min/max for Minutes(1..59), Hours(1..24), Days(1..366),
  Weeks(1..52), Months(1..12). Ticks/Seconds/Ranges visibly unavailable. Missing
  settings preserve old visible behavior, including unsupported interval families.
- Selected trend/rectangle endpoint dates plus tinted timeline span; one-anchor
  drawings one marker. Actual anchors determine span, never extended rays. Reversed/
  coincident/offscreen anchors, collision handling, pan/zoom/resize, future UTC ruler,
  interval changes and controlled echoes work without geometry or data mutations.
- Stats: selected/hover unless Always show enabled. Host supplies exact price_range,
  percent_change, bars_range, date_time_range values through a public typed channel.
  Old values suppressed during geometry drafts. Renderer computes only display
  Distance(px)/Angle(degrees), changing with viewport/scale. Change in pips is
  explicitly unavailable until a registered convention exists. Financial missing
  values remain unavailable, never browser calculated or stale after edits.

## Product persistence contract to align before implementation

Product retains `id/type/currency/adjustment_policy/anchors/color/width/extend_left/
extend_right`; optional `name` (1..120), `visible`, `locked`, and `presentation` add:

```text
line_style?: solid|dashed|dotted
start_cap?, end_cap?: normal|arrow                     [trend only]
middle_point?: boolean                               [paired only]
price_labels?: boolean                               [not vertical]
text?: {value: string, color: #RRGGBB, font_size: 8..48 integer,
        bold: boolean, italic: boolean,
        vertical_alignment: top|middle|bottom,
        horizontal_alignment: left|center|right}
statistics?: (price_range|percent_change|change_in_pips|bars_range|
              date_time_range|distance|angle)[]         [paired only, unique]
statistics_position?: left|center|right|auto           [paired only]
always_show_statistics?: boolean                     [paired only]
visibility?: {minutes?,hours?,days?,weeks?,months?:
              {enabled: boolean, min: positive integer, max: positive integer}}
```

All fields optional except fields within explicitly supplied text/range objects;
null/unknown keys rejected. Public shared API should document an explicit mapping
of these settings to DrawingState (prefer typed `parameters.presentation` with
camelCase equivalents; existing dashStyle may stay authoritative). No opaque
renderer state persisted. Return exact types, coordinate metadata, supplied-stat
and controlled-position props early so product can integrate without guessing.

## Exhaustive receiver write scope

Within `C:/Users/aapae/Documents/Projects/Aidans-React-UI`:

- `charts-market/src/drawings/`
- `charts-market/src/components/technical-chart-view/`
- `charts-market/src/components/market-chart/`
- `charts-market/src/engine/`
- `charts-market/src/core/`
- `charts-market/src/types.ts`
- `charts-market/src/index.ts`
- `charts-market/src/react.ts`
- `charts-market/README.md`
- `charts-market/INTERACTIONS.md`
- `charts-market/DRAWING-EDITOR.md`
- `docs/ROADMAP.md`
- `.chart-drawing-editor-validation/`

Everything else is read-only. Read applicable AGENTS; record baseline HEAD/status
and preserve overlapping dirty work. Authorize implementation, focused offline
tests, existing installed-dependency builds/Storybook/Dev Runner/browser checks
and sealed candidate creation within this allowlist. Report necessary amendments
before exceeding it. No publication, version/manifest/lock change, download,
commit/push/PR, provider/database operation, product edits or cross-chat messages.
Return API/schema mapping and final deliverables here for the initiating product
chat to read; owner authorized messages into this existing chat, not replies out.

## Acceptance

Test all four tools; drag/resize/keyboard/cancel; locked/hidden states; atomic
settings history; exact decimal edits; timeline collisions/offscreen/future anchors;
all intervals, supplied stats freshness and zero financial browser calculation.
Stories cover desktop, 390/320px, light/dark, touch emulation, enlarged 200% view,
four instances and unmodified Board behavior. Distinguish emulation from physical
devices/native browser zoom. Return actual test/browser evidence, public examples,
sealed source/package hashes and a concrete publication review. Publication and
consumer exact-version/complete-lock/install approvals remain separate gates.

## Reviewed scope amendment: fullscreen portals (October 28)

The primary product chat reviewed the prepared amendment and all 12 original
hashes against the UI-kit baseline. Optional portal destinations are necessary to
keep the requested editor dialogs, menus and tooltips within browser fullscreen.
This reversible implementation is within the owner's approved shared UI/dialog
work; the initial handoff required amendments to be reported before exceeding
its scope, and did not impose an additional human source-edit approval gate.

Extend the exhaustive write allowlist by exactly these files, relative to the
same UI-kit repository:

- `src/components/dialog/index.tsx`
- `src/components/dialog/README.md`
- `src/components/dialog/agents.md`
- `src/components/popover/index.tsx`
- `src/components/popover/README.md`
- `src/components/popover/agents.md`
- `src/components/dropdown-menu/index.tsx`
- `src/components/dropdown-menu/README.md`
- `src/components/dropdown-menu/agents.md`
- `src/components/tooltip/index.tsx`
- `src/components/tooltip/README.md`
- `src/components/tooltip/agents.md`

Apply only the reviewed additive `portalContainer` API changes prepared in
`.chart-drawing-editor-validation/fullscreen-amendment/after/`, with the exact
before/after bindings recorded in its `changes.json`. Preserve the original
protected-file baseline; only these exact hashes may become guard exceptions.
Omission must keep the existing body portal. Retain focus/dismiss/keyboard,
forwarded refs and all existing public behavior. Do not move DOM manually.

Installed-only isolated UI-kit tests/builds and coordinated local UI/chart candidate
sealing are authorized. All their generated files remain under the existing
`.chart-drawing-editor-validation/` allowlist. Use explicit local validation aliases
where necessary; do not patch installed packages or adopt source into the product.
Record this as primary-chat coordination under the owner-approved implementation,
not a new human publication/dependency approval. Package versions, manifests,
peer minimums, locks, downloads, commits and publication remain read-only pending
their separate explicit human gates. Return paired publication proposals for review.
