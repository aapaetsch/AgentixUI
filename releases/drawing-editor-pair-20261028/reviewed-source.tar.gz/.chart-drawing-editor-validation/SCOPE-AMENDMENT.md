# Reviewed fullscreen portal correction — primary-chat scope amendment

The request's exhaustive allowlist says “Everything else is read-only.” It excludes
the UI-kit primitives used by the drawing editor. Independent tests reproduce
three failures: in browser fullscreen the toolbar is inside the fullscreen chart,
but Settings, Quick Color and More render in a body sibling outside that subtree.
The original Content APIs provide no supported container override. Nesting a Portal
does not override their internal body portals. The primary request now explicitly
includes this exact12-file amendment under the owner-approved UI/dialog plan.
REQUEST-AMENDED.md and scope-amendment.json record that coordination, separately
from human publication/dependency approval. The earlier source-edit question is
superseded by that explicit amendment; no human npm approval is claimed.

The exact prepared changes are in fullscreen-amendment/after/, with original bytes
in before/ and before/after SHA-256 in changes.json. Add optional portalContainer
to each Content API, consume it in the existing Radix Portal, preserve omitted body
defaults, and document it. No new dependency, CSS, version, manifest or lock change.
The chart's already-authorized scoped wrappers will pass its fullscreen container.
Avoid manual DOM movement or a second copy of Radix/shadcn controls.

Reviewed additional write paths (only these12):

- src/components/dialog/index.tsx
- src/components/dialog/README.md
- src/components/dialog/agents.md
- src/components/popover/index.tsx
- src/components/popover/README.md
- src/components/popover/agents.md
- src/components/dropdown-menu/index.tsx
- src/components/dropdown-menu/README.md
- src/components/dropdown-menu/agents.md
- src/components/tooltip/index.tsx
- src/components/tooltip/README.md
- src/components/tooltip/agents.md

Also authorize installed-only isolated UI-kit build/tests and sealing both local
UI-kit and chart candidates under the existing validation directory. Both retain
their unchanged workspace manifest/version for review. Publication would require
a later coordinated UI-kit release and chart peer-minimum/version approval; the
currently published UI-kit does not implement this new option. Consumer install,
complete-lock changes and deployment remain separate gates.

The original baseline protected hashes remain preserved. Applied guard exceptions
match these12 exact paths and reviewed before/after hashes. Validate fullscreen membership,
focus/keyboard/dismiss, omission defaults, public types, both builds, Storybook and
actual browser fullscreen before sealing.
