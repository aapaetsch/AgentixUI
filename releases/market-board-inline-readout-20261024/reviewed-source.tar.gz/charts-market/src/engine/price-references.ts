import type {MarketPriceReference} from '../core/types';

/** Copy runtime display input; reject missing evidence instead of deriving a replacement. */
export function acceptedPriceReferences(references: readonly MarketPriceReference[] = []): MarketPriceReference[] {
 const seen=new Set<string>();
 return references.filter(reference=>{
  if(!reference||typeof reference.id!=='string'||!reference.id.trim()||typeof reference.label!=='string'||!reference.label.trim()||!Number.isFinite(reference.price)||(reference.lineStyle!=null&&reference.lineStyle!=='dotted')||seen.has(reference.id))return false;
  seen.add(reference.id);return true;
 }).map(reference=>({...reference}));
}
