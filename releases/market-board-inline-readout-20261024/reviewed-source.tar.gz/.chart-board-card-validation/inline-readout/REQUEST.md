# Chart Board inline readout correction

Owner request, October24: use lowercase `vol`, remove the unrequested Legend
button, and give Chart Board plots slightly more vertical room. The product owns
the20pxcard-height increase; the shared renderer owns legend/copy changes.

Current approved renderer always renders a Legend disclosure whenever groups are
present, and hard-codes Bar volume as the group title. Below540px it also shows
only the first group's primary value. Thus enabling volume adds an unwanted
disclosure/title row, and enabling several averages shows only one inline value.
There is no public legend-disclosure or volume-label override. Do not patch package
bytes or hide renderer internals from the product.

Implement a public Board-suitable presentation option that omits the Legend button
and its otherwise-empty reserved space, while retaining a concise, noninteractive
inline readout for visible studies and supplied volume. Product Board compact and
expanded charts must be able to opt in without changing My Charts defaults. The
volume caption must be exactly `vol`, including the compact readout; avoid duplicate
`vol vol` or direction/color-key captions crowding the plot. Public label metadata
or a narrowly scoped shared presentation option is acceptable. Preserve complete
exact source evidence through the existing host-expanded details, null/warmup and
warning semantics, keyboard/pointer inspection and accessible supplied values.

All selected average lines must remain visible after admission. Inspect each of
20EMA/50SMA/150SMA/200SMA in compact and expanded fixtures, none/one/all selected,
and volume on/off. Do not perform financial calculations, alter request identities,
fabricate missing values or mutate saved study evidence to remove chrome. Keep
title-owned pane actions, hover dots, dotted open references, axis prices/labels,
earnings and drawing behavior intact. Measure actual inline height without adding
blank header bands or reintroducing resize/idle feedback.

Acceptance: no visible or focusable Legend button in the opted-in Board surface;
`vol` beside actual supplied volume; no header allocated when all readouts are
absent; all visible selected studies accessible without a new legend disclosure.
Check dense desktop cards,320/390/430px, light/dark, pointer and keyboard, exact
OHLC/value precision, reference/last-price collisions and stable idle/resizing.
Preserve default full-chart legends and existing APIs. Return implementation/API
mapping, affected tests, real-browser screenshots and an independently reviewed
immutable successor candidate using existing dependencies.

Existing receiving chat: `01a140c1-e3d6-7182-b4f8-735c6a258a5b`, saved UI-kit project
at `C:/Users/aapae/Documents/Projects/Aidans-React-UI`. Reuse it; no duplicate chat.

Exhaustive write allowlist: `charts-market/`, `docs/ROADMAP.md`, and
`.chart-board-card-validation/`. Record baseline HEAD/status; preserve unrelated
work and every existing immutable candidate. All other paths, root dependencies,
locks, product/OpenBB repos and secrets are read-only. Source preparation and
existing-dependency build/tests/browser review only. No package downloads,
publication, source acquisition, database work, commits/pushes/PRs or cross-chat
messages. Publication and exact dependency/lock/install approvals remain separate.

Status: owner explicitly authorized sending this correction on October24. Sent
to the existing chat above for source implementation/review and immutable candidate
preparation. Product height implementation proceeds independently. No publication
or dependency-adoption authorization is inferred from dispatch.
