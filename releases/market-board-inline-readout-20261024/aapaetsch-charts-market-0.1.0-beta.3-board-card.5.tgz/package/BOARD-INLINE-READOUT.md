# Board inline study readout

`TechnicalChartAppearance.studyReadout?: 'inline'` is a runtime presentation opt-in on `TechnicalChartView`, exported from the package root. Apply it to both compact and expanded Board instances. Omission preserves the existing full-chart legends, their `Bar volume` title, `Vol` value label, color keys and disclosure. My Charts requires no change.

```tsx
<TechnicalChartView
  {...existingSuppliedChartProps}
  paneMenuTrigger="none"
  paneMenu={titleMenu.paneMenu}
  onPaneMenuChange={titleMenu.onPaneMenuChange}
  appearance={{
    ...existingAppearance,
    studyReadout: 'inline',
  }}
/>
```

Keep a visible native host-title trigger from `useTechnicalPaneMenu` and the existing host-expanded exact-source details. This option removes the Legend button, group buttons and legend dialog; it adds no replacement disclosure. Every visible study's numeric outputs remain named, color-matched, noninteractive inline values at every width. Multi-output groups include output names. Missing/warmup/rejected observations stay unavailable; zero remains zero. Color-only direction keys do not consume inline space. Bar-volume numeric readouts have exactly one lowercase `vol` caption, with no `Bar volume`, rising/falling or duplicate volume caption on this surface.

Inline display uses the existing public display formatter. Exact supplied numbers, observation/range context, warning/status and producer/coverage descriptions remain in accessible item names/descriptions and titles. `SuppliedStatus`, rejected warnings, host callbacks/slots and original source evidence are untouched. Keep host-expanded details discoverable, including exact OHLC, raw volume, results, warning/provenance and admission evidence. The presentation option is not permission to hide unavailable/warning state or mutate saved studies to remove chrome.

The complete inline header wraps atomic caption/value pairs and reports its actual height. External-title standard panes have no 28px disclosure minimum in this mode; when there are no numeric readouts they reserve zero. Internal pane triggers and workspace handles retain their existing control allocation. Height changes, mode changes and wrapped rows use the same measured header for OHLC and engine geometry. Product card sizing, including the requested 20px increase, remains host-owned.

Study selection/visibility, producer request keys, financial outputs, data admission, version-1 state, drawings/history, earnings, supplied dotted open references, prices/axis badges, inspection and hover dots keep their existing contracts. This option neither calculates averages nor selects sessions or source observations. All selected lines still need host-admitted matching results. Do not install a local archive or alter package bytes; publication and consumer exact-version/complete-lock/install approval remain separate.

See **Market Charts / Board Inline Readout** for supplied none/one/all 20EMA/50SMA/150SMA/200SMA, volume on/off, compact/expanded, narrow, dense, light/dark, warmup and default-compatibility fixtures. These are explicit synthetic producer observations, not financial/provider acceptance or physical-device evidence.
