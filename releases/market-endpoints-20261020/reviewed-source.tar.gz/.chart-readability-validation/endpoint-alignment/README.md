# Price and study endpoint alignment review

Owner-authorized October 20 clarification extends the original moving-average
request to price and all oscillator outputs. The public opt-in and complete display
contract are in `PUBLIC_API.md` and `charts-market/ENDPOINT-LABELS.md`.

The owner's follow-up removes visible indicator names from the outlined boxes.
Final boxes contain values/placement markers only with matching line colors;
complete identity, parameters, timestamp and status remain in accessible labels,
hover titles and existing legends. Single-line rows and the narrower gutter keep
values closer to the matching endpoints and retain more plotting space.

All writes stay under charts-market/, docs/ROADMAP.md and
.chart-readability-validation/. The sealed MA candidate and earlier candidates are
preserved. Dependencies, root UI/icon sources/dist and prior evidence are guarded
by `dev-runner/baseline.json`. Workspace package version remains unchanged; the
new publication candidate uses an isolated manifest version override.

## Evidence

Final validation passed 214 tests across 36 files, strict package/public-example
types, 66 focused story fixtures (15 endpoint, 19 moving-average, 32 adaptive /
readability), lint with zero errors/four existing warnings, ESM/CJS/declarations/CSS,
139-story Storybook, seven public subpaths and six SSR cases. Older broad-story
typing errors are explicitly retained as a limitation. Final browser evidence has
16 cases, 16 interaction records and 24 referenced screenshots, bound to the final
source/build hash. Numeric text bounds, pairwise separation, pane chrome, exact
historical endpoints, crossing order, centered equal groups, reorder/resize/collapse,
larger text, overflow keyboard access and source evidence were verified.

- `dev-runner/final-results.json`: independent test/type/lint/build/Storybook results
  and disclosed limitations, including broad legacy story typing diagnostics.
- `dev-runner/final-audit.json`: runtime/dist bindings and protected file guards.
- `browser-results.json`: executed synthetic browser cases, interactions and limits.
- `candidates/endpoint-labels-<binding>/receipt.json`: exact local npm artifact,
  reviewed source archive, package inventory, license/dependencies and evidence hashes.
- `dev-runner/candidate-review.json` and `candidate-readonly.json`: independent
  artifact verification and local read-only sealing, with exact file hashes.

Browser fixtures use only literal independent supplied values. Geometry checks
inspect renderer DOM only in validation, never in consumer integration. No real
Portfolio cached acceptance, physical mobile/Safari/Firefox or newly installed
React peer version is claimed. Keyboard/accessibility-name/source-evidence checks
are recorded separately from any automated accessibility audit.

No publication, dependency download/change, product/OpenBB/provider/database action,
financial operation, consumer adoption/deployment, commit/push/PR or messages to
other chats are authorized or performed. Publication and exact consumer artifact /
complete-lock adoption remain separate review gates.
