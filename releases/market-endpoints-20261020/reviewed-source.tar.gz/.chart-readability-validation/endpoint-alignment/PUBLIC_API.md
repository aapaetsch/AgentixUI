# Additive endpoint alignment contract

```tsx
appearance={{...existingAppearance, badges: {
  ...existingAppearance.badges,
  visible: true, lastPrice: true, studyValues: true,
  endpointValues: 'all-visible',
}}}
```

- `MarketChartPresentation.badges.endpointValues?: 'all-visible'` applies through
  TechnicalChartView.appearance, MarketChart.presentation and engine.setPresentation.
  It supersedes the older MA-only option, preserves omission defaults and honors
  visible/lastPrice/studyValues toggles.
- `IndicatorRenderSeries.axisLabel.kind` additionally accepts `'study'`. Composite
  adapters provide human names/parameters/output names, duplicate ordinals and
  matching supplied status/warnings for all outputs. No saved/request identity changes.
- Last accepted bar in the actual visible window supplies the common timestamp;
  missing matching output stays nonnumeric. Hover/nearest/previous observations
  never substitute. Source values and original evidence are unchanged.
- Per-pane scale coordinates include actual top offsets after reorder/resizing.
  All visible line and histogram outputs and price close use the same layout.
  Hidden/collapsed panes are excluded without overriding host pane minimums.
- A dedicated right gutter precedes the original tick/crosshair lane. Whole rows
  remain below measured pane chrome and above separators. Order-preserving
  least-squares placement minimizes squared displacement with matching connectors.
  Equal/close values remain identifiable; no suppression for lower-priority ticks.
- Bounded scroll overflow retains all rows with explicit unpositioned semantics.
  Visible boxes show values only with matching outlines/colors; names, parameters
  and ordinals remain in accessible labels/titles and the existing legends.
  Numeric text wraps rather than shrinking/clipping at extreme font/width ratios.
  Manual/log off-scale and invalid-log values remain disclosed without resetting
  scale or changing values. Complete source evidence remains in existing controls.

Public example: charts-market/examples/endpoint-boxes.tsx.
Full documented behavior: charts-market/ENDPOINT-LABELS.md.
