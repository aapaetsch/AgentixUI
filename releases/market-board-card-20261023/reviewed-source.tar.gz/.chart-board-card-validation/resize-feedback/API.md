# Resize feedback successor: public API mapping

The predecessor Board candidate and timeline release stay immutable. This local successor retains the Board title-menu, line-marker, Log policy, disabled-row and details opt-out mappings in `../API.md`.

The separate compact projection correction in `../compact-geometry/PUBLIC-MAPPING.md` remains necessary: workspace `size: 4` requests a 400px pane; compact `size: .56, minimumSize: 56` permits the available plot allocation to fill normally. Expanded preferences remain separate.

The newly reported 120/237px oscillation is a different shared composition defect. Natural content and live canvas-host allocation are now measured within the same DOM layout. The hook no longer subtracts a newly reported engine extent from a previous React allocation. `onGeometryChange` remains supported on compact cards and may update host state. Memoizing appearance/interaction objects can reduce incidental work but is not a correctness requirement. New synthetic Resize Feedback stories deliberately use fresh props and an active geometry callback.

`TechnicalChartGeometry.renderedPlotHeight` and `intrinsicHeight` in workspace mode describe committed DOM allocation and natural content. Engine height callbacks can precede React allocation; they trigger reconciliation rather than supply a different-commit subtraction. Keep available slot height independent from content allocation and honor genuine pane/chrome overflow through the existing public host-scroller pattern.

Low-level `MarketChartProps.canvasHostRef?: React.Ref<HTMLDivElement>` is additive. It receives the live allocation element for explicit composed measurement without selectors or ancestor lookup. Existing ref/imperative handles and defaults remain compatible. The composite supplies this ref internally, so Portfolio does not need to inspect DOM, query private selectors, introduce a second geometry engine, or use this low-level ref.

Canvas resize now updates bitmap width/height only when the corresponding physical pixel count changes; unchanged dimensions retain the Canvas2D buffer/context. Actual dimensions and device-pixel-ratio changes still resize it, and content-height notification occurs after bitmap/CSS updates. Data, revision identity, formulas, providers, saved state and gesture ownership are unchanged.

This successor is local only. Tests and synthetic browser checks cannot establish Portfolio adoption or real hardware acceptance. Publication, exact-version/complete-lock/scripts-disabled installation and real supplied-data compact/expanded verification remain separate decisions.
