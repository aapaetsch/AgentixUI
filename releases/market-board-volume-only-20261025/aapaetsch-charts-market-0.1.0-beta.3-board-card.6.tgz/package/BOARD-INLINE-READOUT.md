# Board inline study readout

`TechnicalChartAppearance.studyReadout?: 'inline' | 'volume-only'` is a runtime presentation opt-in on `TechnicalChartView`, exported from the package root. Use `'volume-only'` for compact Boards with a shared page-level average key and retain `'inline'` for expanded Boards. Existing `'inline'` consumers keep their behavior. Omission preserves the existing full-chart legends, their `Bar volume` title, `Vol` value label, color keys and disclosure. My Charts requires no change.

## Compact shared-key policy

```tsx
appearance={{
  ...existingAppearance,
  studyReadout: expanded ? 'inline' : 'volume-only',
}}
```

`'volume-only'` removes indicator, VWAP, drawing and profile legend names, swatches and numeric entries from the compact readout. It shows only actual supplied bar volume with one lowercase `vol` caption. Finite zero remains `vol 0`. Hidden, missing, null or nonfinite volume and no accepted bars produce no row or disclosure; with the external title menu, their header reserves zero height. Inspection uses the exact inspected bar, never a latest/nearby substitute for an unavailable observation. Clearing inspection restores latest supplied volume.

Selected studies and their supplied points, strokes, right-axis badges, volume histogram, OHLC, daily-open reference, hover dot, earnings, warnings and request identities are unchanged. Expanded charts must use `'inline'` and retain discoverable complete original evidence, provenance and warning/rejection details. Hiding a compact legend does not make partial or rejected results available. No extra per-card status row is introduced. With compact supplied status and details disabled, long critical warnings remain complete in the existing status surface, bounded to 4rem and keyboard-scrollable with visible focus. Positive status has no new tab stop; expanded inline/default warnings retain their existing layout. Hosts must still allocate enough height for their chosen root font and minimum plot.

The page-level checkbox key is host-owned. Portfolio's current factory palette maps 20 EMA to study1, 50 MA to study2, 150 MA to study3 and 200 MA to study4 in each light/dark theme. Use the same period/output/theme/override resolution as the chart adapter, independent of selection order or sparse points. Swatches are decorative line samples beside named native checkboxes. Card sizing remains host-owned; this option requires no height increase.

See **Market Charts / Board Shared Average Legend** for fixed supplied fixtures within 290px desktop / 310px narrow cards, shared checkbox colors, compact/expanded/default policies, volume zero/missing/off/no bars and sparse/null/partial/rejected evidence.

## Complete inline policy

```tsx
<TechnicalChartView
  {...existingSuppliedChartProps}
  paneMenuTrigger="none"
  paneMenu={titleMenu.paneMenu}
  onPaneMenuChange={titleMenu.onPaneMenuChange}
  appearance={{
    ...existingAppearance,
    studyReadout: 'inline',
  }}
/>
```

Keep a visible native host-title trigger from `useTechnicalPaneMenu` and the existing host-expanded exact-source details. This option removes the Legend button, group buttons and legend dialog; it adds no replacement disclosure. Every visible study's numeric outputs remain named, color-matched, noninteractive inline values at every width. Multi-output groups include output names. Missing/warmup/rejected observations stay unavailable; zero remains zero. Color-only direction keys do not consume inline space. Bar-volume numeric readouts have exactly one lowercase `vol` caption, with no `Bar volume`, rising/falling or duplicate volume caption on this surface.

Inline display uses the existing public display formatter. Exact supplied numbers, observation/range context, warning/status and producer/coverage descriptions remain in accessible item names/descriptions and titles. `SuppliedStatus`, rejected warnings, host callbacks/slots and original source evidence are untouched. Keep host-expanded details discoverable, including exact OHLC, raw volume, results, warning/provenance and admission evidence. The presentation option is not permission to hide unavailable/warning state or mutate saved studies to remove chrome.

The complete inline header wraps atomic caption/value pairs and reports its actual height. External-title standard panes have no 28px disclosure minimum in this mode; when there are no numeric readouts they reserve zero. Internal pane triggers and workspace handles retain their existing control allocation. Height changes, mode changes and wrapped rows use the same measured header for OHLC and engine geometry. Product card sizing, including the requested 20px increase, remains host-owned.

Study selection/visibility, producer request keys, financial outputs, data admission, version-1 state, drawings/history, earnings, supplied dotted open references, prices/axis badges, inspection and hover dots keep their existing contracts. This option neither calculates averages nor selects sessions or source observations. All selected lines still need host-admitted matching results. Do not install a local archive or alter package bytes; publication and consumer exact-version/complete-lock/install approval remain separate.

See **Market Charts / Board Inline Readout** for supplied none/one/all 20EMA/50SMA/150SMA/200SMA, volume on/off, compact/expanded, narrow, dense, light/dark, warmup and default-compatibility fixtures. These are explicit synthetic producer observations, not financial/provider acceptance or physical-device evidence.
