# Consumer API mapping

```tsx
<TechnicalChartView
  {...existingSuppliedChartProps}
  paneMenuTrigger="none"
  paneMenu={titleMenu.paneMenu}
  onPaneMenuChange={titleMenu.onPaneMenuChange}
  appearance={{
    ...existingAppearance,
    studyReadout: expanded ? 'inline' : 'volume-only',
  }}
/>
```

Additive root-exported TechnicalChartAppearance.studyReadout: 'inline' | 'volume-only' | undefined. Keep host-title useTechnicalPaneMenu trigger, admitted supplied results, selected studies, all-visible moving-average badges, hover marker, priceReferences, earnings and complete source evidence unchanged. This policy is not saved and creates no calculation/request input. Existing inline callers and omitted defaults retain their behavior.

Compact volume-only renders one noninteractive lowercase vol caption and its finite supplied observation; zero is valid. Hidden/missing/null/nonfinite/no-bar volume yields no row, no hidden legend controls and zero external-title header height. It removes other groups' names, swatches and numbers without removing their series, badges or warning/admission semantics. Inspection uses the exact accepted bar; it does not substitute latest volume into an unavailable inspection. Internal menu/workspace control minima stay intact.

Expanded charts continue to show every selected numeric group with inline, including unavailable placeholders and exact title/accessible values. Keep host-expanded original result/request/warning/provenance/source evidence discoverable. Rejected results remain rejected, and no extra per-card status row is introduced by this option. For compact status with details disabled, the existing critical-warning surface is bounded to 4rem with visible focus and native keyboard scrolling; every warning/rejection/critical availability description remains in its accessible DOM. Ordinary positive status adds no tab stop. Expanded inline and omitted defaults retain their original status layout. Extreme host font/minimum/slot combinations can still require more height; do not suppress warnings to force a fit.

Portfolio's prepared page swatches map 20 EMA/study1, 50 MA/study2, 150 MA/study3, 200 MA/study4. Defaults: light #2563eb/#9333ea/#b45309/#0891b2; dark #60a5fa/#c084fc/#fbbf24/#22d3ee. Resolve periods/output/theme and any overrides identically in the host key and adapter; selection order or sparse data must not choose colors. Swatches remain decorative beside named keyboard-operable checkboxes, including before data loads.

No product source was changed. After separate publication/adoption approval, the consumer must map only compact Board instances to volume-only, keep expanded inline and omitted My Charts, install the exact published version with a reviewed complete lock, rebuild and verify its real cards. Local synthetic stories at 290px desktop/310px narrow and emulated 320/390/430px are not real-provider or physical-device acceptance.
