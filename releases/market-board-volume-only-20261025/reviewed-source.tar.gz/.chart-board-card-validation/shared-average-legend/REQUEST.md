# Shared moving-average key for Chart Boards

Status: owner-authorized dispatch sent to the existing UI-kit chart chat on
October 24. Source implementation/review is pending; publication and product
dependency adoption are not authorized by that dispatch.
Owner request, October 24: put moving-average line colors beside the four page-level
checkboxes instead of repeating their legend in every chart card. The owner then
explicitly selected removal of the entire moving-average legend row, including
numbers, from compact cards; supplied values stay available in expanded details.

The completed inline-readout adoption is committed as b07d025. This request is a
new, narrow presentation refinement. It does not authorize a renderer replacement,
private DOM/CSS overrides, package edits, financial computation or source work.

## Consumer composition

Portfolio owns the checkbox controls in
`frontend/components/chart-boards-workspace.tsx` and their styles in
`frontend/components/chart-boards.module.css`. The prepared swatches call the same
public product `studyColors` helper/factory theme palette as its chart adapter:
20 EMA uses study1, 50 SMA study2, 150 SMA study3 and 200 SMA study4. Colors follow
the active light/dark surface, not checkbox selection order. Every checkbox keeps
its existing accessible period/type name and keyboard behavior. A swatch is a
decorative, noninteractive line sample, never another button or data calculation.
The shared key is visible even before a card has price history.

The current receiver-approved package exposes only `studyReadout: 'inline'`.
It always renders every visible numeric study group. `legendMetadata` offers
drawing/profile names, not per-study legend suppression. `badges.studyValues`
controls price-axis boxes, not the card legend. Do not hide plotted studies or
their badges to remove the readout, and do not alter admitted calculation results.

## Requested public renderer behavior

Add a backward-compatible public compact readout policy that shows only supplied
bar volume, captioned exactly `vol`, and omits indicator legend names, swatches
and numeric entries. For example, extend `appearance.studyReadout` with
`'volume-only'`; an equivalent documented public API is acceptable. It must retain
the existing `'inline'` behavior and omitted-option My Charts defaults.

The product will opt compact Board cards into this policy. Expanded Board charts
will continue to use `'inline'`, with all selected supplied numeric values, exact
host evidence and provenance. Keep the four selected average lines, existing
price-axis value badges, daily-open reference, crosshair/hover dot, volume histogram,
OHLC and title-owned pane menu. Do not introduce a Legend button, new disclosure,
extra status row or another per-card color key. A compact price-axis box is not
the repeated legend row and is outside this removal request.

When volume is hidden or unavailable and no visible readout remains, allocate zero
legend-row height. OHLC starts immediately below actual preceding chrome; the
released space returns to the plot within the existing 290px desktop/310px phone
cards. Card height, economic viewport, acquisition bounds and saved evidence stay
unchanged. Positive status/coverage warnings, rejected-result semantics and exact
source access must not disappear as a side effect of hiding presentation groups.

## UI states, accessibility, themes and acceptance

- Stories/fixtures: none, one and all four averages; volume on/off/missing; no bars;
  warm-up/null/partial/rejected evidence; compact and expanded; unchanged My Charts.
- Compact opt-in: no indicator legend entries or hidden focusable legend controls;
  supplied `vol` remains when enabled. The four lines and their price-axis badges
  still render. Expanding exposes each selected numeric readout and host evidence.
- Check the shared page-key mapping against actual engine stroke colors for all
  four periods, in light and dark, independent of selection order and sparse data.
- Responsive review at dense three-column desktop and 320/390/430 CSSpx. No empty
  ticker/readout band, clipped OHLC, horizontal overflow or extra card height.
- Pointer/keyboard inspection, title menu focus return, hover dot, open/last-price
  references, earnings and volumes retain existing behavior. Names/values remain
  available in expanded accessible content; no color-only control labels.
- Measured actual chrome height, stable resize and settled idle; no resize/paint
  feedback loop. Verify exact supplied values and warning/null semantics unchanged.
- No new dependencies, financial formulas, provider acquisition or saved-state
  migration. Return public API mapping, affected tests, real browser evidence,
  independent review and an immutable candidate. Do not infer publication/adoption.

## Recipient and exact operational boundary

Existing UI-kit chart chat: `01a140c1-e3d6-7182-b4f8-735c6a258a5b`.
Saved project: `C:/Users/aapae/Documents/Projects/Aidans-React-UI`.
Product URL: [Chart Boards](http://localhost:3000/chart-boards).
Reuse that chat; do not create another task or message other chats.

Exhaustive write allowlist: `charts-market/`, `docs/ROADMAP.md` and
`.chart-board-card-validation/`. Record baseline HEAD/status; preserve unrelated
work, existing immutable candidates and old API behavior. All other workspace
paths, root dependencies/locks, Portfolio/OpenBB repos and secrets are read-only.
Source preparation, existing-dependency build/tests and local browser review only.
No package downloads, publication, commits, pushes, PRs, source acquisition,
database operations, service deployments or cross-chat messages. A returned
candidate still needs separate publication and exact npm/lock/install approvals.
